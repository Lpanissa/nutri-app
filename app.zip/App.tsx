import './src/alertShim';
import React, { useEffect, useRef, useState } from 'react';
import { View, Text, TouchableOpacity, SafeAreaView, StatusBar, Platform, Image, Animated } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C } from './src/theme';
import { Meal, Body, Recipe } from './src/types';
import { Store } from './src/storage';
import Hoje from './src/Hoje';
import Calendario from './src/Calendario';
import Corpo from './src/Corpo';
import Dicas from './src/Dicas';
import Ajustes from './src/Ajustes';
import Auth from './src/Auth';
import Perfil, { Avatar } from './src/Perfil';
import { auth, FA } from './src/firebase';
import { setUser, Profile } from './src/storage';
import { ActivityIndicator, useWindowDimensions } from 'react-native';
import Privacidade from './src/Privacidade';

const TABS: { id: string; label: string; icon: string }[] = [
  { id: 'hoje', label: 'Hoje', icon: 'nutrition' },
  { id: 'cal', label: 'Agenda', icon: 'calendar' },
  { id: 'corpo', label: 'Corpo', icon: 'body' },
  { id: 'dicas', label: 'Dicas', icon: 'leaf' },
  { id: 'ajustes', label: 'Conta', icon: 'person' },
];

const DIAS = ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado'];
const MESES = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];

function Intro({ onDone }: { onDone: () => void }) {
  const logo = useRef(new Animated.Value(0)).current;
  const txt = useRef(new Animated.Value(0)).current;
  const out = useRef(new Animated.Value(1)).current;
  useEffect(() => {
    Animated.sequence([
      Animated.timing(logo, { toValue: 1, duration: 700, useNativeDriver: true }),
      Animated.timing(txt, { toValue: 1, duration: 500, useNativeDriver: true }),
      Animated.delay(700),
      Animated.timing(out, { toValue: 0, duration: 450, useNativeDriver: true }),
    ]).start(() => onDone());
  }, []);
  return (
    <Animated.View
      pointerEvents="none"
      style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: C.green, alignItems: 'center', justifyContent: 'center', opacity: out }}
    >
      <Animated.Image
        source={require('./assets/splash-icon.png')}
        style={{ width: 200, height: 200, opacity: logo, transform: [{ scale: logo.interpolate({ inputRange: [0, 1], outputRange: [0.7, 1] }) }] }}
      />
      <Animated.View style={{ opacity: txt, transform: [{ translateY: txt.interpolate({ inputRange: [0, 1], outputRange: [10, 0] }) }], alignItems: 'center' }}>
        <Text style={{ color: '#fff', fontSize: 28, fontWeight: '700', letterSpacing: 0.5 }}>Mavité</Text>
        <Text style={{ color: '#DDEBDD', fontSize: 14, marginTop: 6, letterSpacing: 1 }}>comer bem, viver melhor</Text>
      </Animated.View>
    </Animated.View>
  );
}

function Main({ email, uid, nomeInicial }: { email: string; uid: string; nomeInicial: string }) {
  const [perfil, setPerfil] = useState(false);
  const [prof, setProf] = useState<Profile>({ nome: nomeInicial });
  const [tab, setTab] = useState('hoje');
  const [intro, setIntro] = useState(true);
  const [meals, setMeals] = useState<Meal[]>([]);
  const [body, setBody] = useState<Body[]>([]);
  const [recipes, setRecipes] = useState<Recipe[]>([]);

  useEffect(() => {
    Store.profile({ nome: nomeInicial }).then((p) => setProf(p.nome ? p : { ...p, nome: nomeInicial }));
    Store.meals().then(setMeals);
    Store.body().then(setBody);
    Store.recipes().then(setRecipes);
  }, []);

  const now = new Date();
  const data = DIAS[now.getDay()] + ', ' + now.getDate() + ' de ' + MESES[now.getMonth()];

  const { width } = useWindowDimensions();
  const desk = Platform.OS === 'web' && width >= 900;
  const [priv, setPriv] = useState(false);
  const content = (
    <View style={{ flex: 1 }}>
      {tab === 'hoje' && <Hoje meals={meals} setMeals={setMeals} />}
      {tab === 'cal' && <Calendario meals={meals} setMeals={setMeals} />}
      {tab === 'corpo' && <Corpo body={body} setBody={setBody} />}
      {tab === 'dicas' && <Dicas recipes={recipes} setRecipes={setRecipes} />}
      {tab === 'ajustes' && <Ajustes email={email} onPerfil={() => setPerfil(true)} onPrivacidade={() => setPriv(true)} onLogout={() => FA.signOut(auth)} />}
    </View>
  );

  return (
    <View style={{ flex: 1, backgroundColor: desk ? '#F1F4EE' : C.bg, flexDirection: desk ? 'row' : 'column' }}>
      {desk && (
        <View style={{ width: 250, backgroundColor: C.card, borderRightWidth: 1, borderRightColor: C.line, padding: 20 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 28, marginTop: 6 }}>
            <View style={{ width: 40, height: 40, borderRadius: 12, backgroundColor: C.green, alignItems: 'center', justifyContent: 'center', marginRight: 10 }}>
              <Image source={require('./assets/splash-icon.png')} style={{ width: 28, height: 28 }} />
            </View>
            <Text style={{ fontSize: 22, fontWeight: '800', color: C.text }}>Mavité</Text>
          </View>
          {TABS.map((t) => {
            const on = tab === t.id;
            return (
              <TouchableOpacity key={t.id} onPress={() => setTab(t.id)} style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 12, paddingHorizontal: 14, borderRadius: 14, marginBottom: 4, backgroundColor: on ? C.greenLight : 'transparent' }}>
                <Ionicons name={(on ? t.icon : t.icon + '-outline') as any} size={22} color={on ? C.green : C.muted} />
                <Text style={{ marginLeft: 12, fontSize: 15, fontWeight: on ? '700' : '500', color: on ? C.green : C.text }}>{t.label}</Text>
              </TouchableOpacity>
            );
          })}
          <View style={{ flex: 1 }} />
          <TouchableOpacity onPress={() => setPerfil(true)} style={{ flexDirection: 'row', alignItems: 'center', padding: 10, borderRadius: 14, backgroundColor: C.greenLight }}>
            <Avatar p={prof} size={40} />
            <View style={{ marginLeft: 10, flex: 1 }}>
              <Text style={{ fontWeight: '700', color: C.text }} numberOfLines={1}>{prof.nome}</Text>
              <Text style={{ fontSize: 12, color: C.muted }}>Ver perfil</Text>
            </View>
          </TouchableOpacity>
        </View>
      )}
      <SafeAreaView style={{ flex: 1, paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight || 0 : 0, alignItems: 'center' }}>
        <StatusBar barStyle="dark-content" backgroundColor={C.bg} />
        <View style={{ flex: 1, width: '100%', maxWidth: desk ? 880 : 680 }}>
          <View style={{ paddingHorizontal: desk ? 28 : 20, paddingTop: desk ? 26 : 12, paddingBottom: 6, flexDirection: 'row', alignItems: 'center' }}>
            {!desk && (
              <TouchableOpacity onPress={() => setPerfil(true)} style={{ marginRight: 12 }}>
                <Avatar p={prof} size={46} />
              </TouchableOpacity>
            )}
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: desk ? 26 : 19, fontWeight: '700', color: C.text }}>Olá, {(prof.nome || '').split(' ')[0]}</Text>
              <Text style={{ fontSize: 12.5, color: C.muted, marginTop: 1 }}>{data}</Text>
            </View>
            {!desk && <Image source={require('./assets/logo.png')} style={{ width: 26, height: 26, opacity: 0.9 }} />}
          </View>
          {content}
          {!desk && (
            <View
              style={{
                flexDirection: 'row', backgroundColor: C.card, marginHorizontal: 14, marginBottom: 12, marginTop: 4, borderRadius: 28, padding: 6,
                shadowColor: '#1F3A2A', shadowOpacity: 0.15, shadowRadius: 16, shadowOffset: { width: 0, height: 6 }, elevation: 10,
              }}
            >
              {TABS.map((t) => {
                const on = tab === t.id;
                return (
                  <TouchableOpacity
                    key={t.id}
                    onPress={() => setTab(t.id)}
                    style={{ flex: on ? 2 : 1, height: 48, borderRadius: 22, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', backgroundColor: on ? C.green : 'transparent' }}
                  >
                    <Ionicons name={(on ? t.icon : t.icon + '-outline') as any} size={22} color={on ? '#fff' : C.muted} />
                    {on ? <Text style={{ color: '#fff', fontWeight: '600', fontSize: 13, marginLeft: 6 }}>{t.label}</Text> : null}
                  </TouchableOpacity>
                );
              })}
            </View>
          )}
        </View>
      </SafeAreaView>
      {perfil && <Perfil profile={prof} email={email} onSave={setProf} onClose={() => setPerfil(false)} onLogout={() => FA.signOut(auth)} />}
      {priv && <Privacidade onClose={() => setPriv(false)} />}
      {intro && <Intro onDone={() => setIntro(false)} />}
    </View>
  );
}

export default function App() {
  const [user, setU] = useState<any>(undefined);
  useEffect(() => FA.onAuthStateChanged(auth, (u) => { if (u) setUser(u.uid); setU(u || null); }), []);
  if (user === undefined) {
    return (
      <View style={{ flex: 1, backgroundColor: C.green, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator color="#fff" />
      </View>
    );
  }
  if (!user) return <Auth />;
  const nome = user.displayName || (user.email ? String(user.email).split('@')[0] : 'Você');
  return <Main key={user.uid} email={user.email || ''} uid={user.uid} nomeInicial={nome} />;
}
