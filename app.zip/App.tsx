import React, { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, SafeAreaView, StatusBar, Platform } from 'react-native';
import { C } from './src/theme';
import { Meal, Body, Recipe } from './src/types';
import { Store } from './src/storage';
import Hoje from './src/Hoje';
import Calendario from './src/Calendario';
import Corpo from './src/Corpo';
import Dicas from './src/Dicas';
import Ajustes from './src/Ajustes';

const TABS = [
  { id: 'hoje', label: 'Hoje' },
  { id: 'cal', label: 'Calendário' },
  { id: 'corpo', label: 'Corpo' },
  { id: 'dicas', label: 'Dicas' },
  { id: 'ajustes', label: 'Ajustes' },
];

export default function App() {
  const [tab, setTab] = useState('hoje');
  const [meals, setMeals] = useState<Meal[]>([]);
  const [body, setBody] = useState<Body[]>([]);
  const [recipes, setRecipes] = useState<Recipe[]>([]);

  useEffect(() => {
    Store.meals().then(setMeals);
    Store.body().then(setBody);
    Store.recipes().then(setRecipes);
  }, []);

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.bg, paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight || 0 : 0 }}>
      <StatusBar barStyle="dark-content" backgroundColor={C.bg} />
      <View style={{ paddingHorizontal: 20, paddingTop: 14, flexDirection: 'row', alignItems: 'center' }}>
        <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: C.green, marginRight: 8 }} />
        <Text style={{ fontSize: 13, color: C.green, letterSpacing: 2, fontWeight: '600' }}>NUTRI</Text>
      </View>
      <View style={{ flex: 1 }}>
        {tab === 'hoje' && <Hoje meals={meals} setMeals={setMeals} />}
        {tab === 'cal' && <Calendario meals={meals} setMeals={setMeals} />}
        {tab === 'corpo' && <Corpo body={body} setBody={setBody} />}
        {tab === 'dicas' && <Dicas recipes={recipes} setRecipes={setRecipes} />}
        {tab === 'ajustes' && <Ajustes />}
      </View>
      <View style={{ flexDirection: 'row', backgroundColor: C.card, borderTopWidth: 1, borderColor: C.line }}>
        {TABS.map((t) => {
          const on = tab === t.id;
          return (
            <TouchableOpacity key={t.id} onPress={() => setTab(t.id)} style={{ flex: 1, alignItems: 'center', paddingBottom: 12, paddingTop: 0 }}>
              <View style={{ height: 2, alignSelf: 'stretch', marginHorizontal: 14, backgroundColor: on ? C.green : 'transparent', marginBottom: 10 }} />
              <Text style={{ fontSize: 12, color: on ? C.green : C.muted, fontWeight: on ? '600' : '400', letterSpacing: 0.3 }}>{t.label}</Text>
            </TouchableOpacity>
          );
        })}
      </View>
    </SafeAreaView>
  );
}
