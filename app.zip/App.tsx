import React, { useEffect, useRef, useState } from 'react';
import { View, Text, TouchableOpacity, SafeAreaView, StatusBar, Platform, Image, Animated } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C } from './src/theme';
import { Meal, Body, Recipe } from './src/types';
import { Store } from './src/storage';
import Hoje from './src/Hoje';
import Calendario from './src/Calendario';
import Corpo from './src/Corpo';
import Dicas from './src/Dicas';
import Ajustes from './src/Ajustes';

const TABS: { id: string; label: string; icon: string }[] = [
  { id: 'hoje', label: 'Hoje', icon: 'nutrition' },
  { id: 'cal', label: 'Agenda', icon: 'calendar' },
  { id: 'corpo', label: 'Corpo', icon: 'body' },
  { id: 'dicas', label: 'Dicas', icon: 'leaf' },
  { id: 'ajustes', label: 'Ajustes', icon: 'settings' },
];

const DIAS = ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado'];
const MESES = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];

function Intro({ onDone }: { onDone: () => void }) {
  const logo = useRef(new Animated.Value(0)).current;
  const txt = useRef(new Animated.Value(0)).current;
  const out = useRef(new Animated.Value(1)).current;
  useEffect(() => {
    Animated.sequence([
      Animated.timing(logo, { toValue: 1, duration: 700, useNativeDriver: true }),
      Animated.timing(txt, { toValue: 1, duration: 500, useNativeDriver: true }),
      Animated.delay(700),
      Animated.timing(out, { toValue: 0, duration: 450, useNativeDriver: true }),
    ]).start(() => onDone());
  }, []);
  return (
    <Animated.View
      pointerEvents="none"
      style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: C.green, alignItems: 'center', justifyContent: 'center', opacity: out }}
    >
      <Animated.Image
        source={require('./assets/splash-icon.png')}
        style={{ width: 200, height: 200, opacity: logo, transform: [{ scale: logo.interpolate({ inputRange: [0, 1], outputRange: [0.7, 1] }) }] }}
      />
      <Animated.View style={{ opacity: txt, transform: [{ translateY: txt.interpolate({ inputRange: [0, 1], outputRange: [10, 0] }) }], alignItems: 'center' }}>
        <Text style={{ color: '#fff', fontSize: 28, fontWeight: '700', letterSpacing: 0.5 }}>Nutri da Maiury</Text>
        <Text style={{ color: '#DDEBDD', fontSize: 14, marginTop: 6, letterSpacing: 1 }}>comer bem, viver melhor</Text>
      </Animated.View>
    </Animated.View>
  );
}

export default function App() {
  const [tab, setTab] = useState('hoje');
  const [intro, setIntro] = useState(true);
  const [meals, setMeals] = useState<Meal[]>([]);
  const [body, setBody] = useState<Body[]>([]);
  const [recipes, setRecipes] = useState<Recipe[]>([]);

  useEffect(() => {
    Store.meals().then(setMeals);
    Store.body().then(setBody);
    Store.recipes().then(setRecipes);
  }, []);

  const now = new Date();
  const data = DIAS[now.getDay()] + ', ' + now.getDate() + ' de ' + MESES[now.getMonth()];

  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <SafeAreaView style={{ flex: 1, paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight || 0 : 0 }}>
        <StatusBar barStyle="dark-content" backgroundColor={C.bg} />
        <View style={{ paddingHorizontal: 20, paddingTop: 12, paddingBottom: 6, flexDirection: 'row', alignItems: 'center' }}>
          <View style={{ width: 44, height: 44, borderRadius: 14, backgroundColor: C.greenLight, alignItems: 'center', justifyContent: 'center', marginRight: 12 }}>
            <Image source={require('./assets/logo.png')} style={{ width: 28, height: 28 }} />
          </View>
          <View>
            <Text style={{ fontSize: 19, fontWeight: '700', color: C.text }}>Nutri da Maiury</Text>
            <Text style={{ fontSize: 12.5, color: C.muted, marginTop: 1 }}>{data}</Text>
          </View>
        </View>
        <View style={{ flex: 1 }}>
          {tab === 'hoje' && <Hoje meals={meals} setMeals={setMeals} />}
          {tab === 'cal' && <Calendario meals={meals} setMeals={setMeals} />}
          {tab === 'corpo' && <Corpo body={body} setBody={setBody} />}
          {tab === 'dicas' && <Dicas recipes={recipes} setRecipes={setRecipes} />}
          {tab === 'ajustes' && <Ajustes />}
        </View>
        <View
          style={{
            flexDirection: 'row', backgroundColor: C.card, marginHorizontal: 14, marginBottom: 12, marginTop: 4, borderRadius: 28, padding: 6,
            shadowColor: '#1F3A2A', shadowOpacity: 0.15, shadowRadius: 16, shadowOffset: { width: 0, height: 6 }, elevation: 10,
          }}
        >
          {TABS.map((t) => {
            const on = tab === t.id;
            return (
              <TouchableOpacity
                key={t.id}
                onPress={() => setTab(t.id)}
                style={{
                  flex: on ? 2 : 1, height: 48, borderRadius: 22, alignItems: 'center', justifyContent: 'center', flexDirection: 'row',
                  backgroundColor: on ? C.green : 'transparent',
                }}
              >
                <Ionicons name={(on ? t.icon : t.icon + '-outline') as any} size={22} color={on ? '#fff' : C.muted} />
                {on ? <Text style={{ color: '#fff', fontWeight: '600', fontSize: 13, marginLeft: 6 }}>{t.label}</Text> : null}
              </TouchableOpacity>
            );
          })}
        </View>
      </SafeAreaView>
      {intro && <Intro onDone={() => setIntro(false)} />}
    </View>
  );
}
