import { Alert, Platform } from 'react-native';

if (Platform.OS === 'web') {
  (Alert as any).alert = (title: string, message?: string, buttons?: any[]) => {
    const text = [title, message].filter(Boolean).join('\n\n');
    if (!buttons || buttons.length < 2) {
      window.alert(text);
      if (buttons && buttons[0] && buttons[0].onPress) buttons[0].onPress();
      return;
    }
    const ok = window.confirm(text);
    const act = buttons.find((b) => b.style !== 'cancel' && b.onPress);
    const cancel = buttons.find((b) => b.style === 'cancel' && b.onPress);
    if (ok && act) act.onPress();
    else if (!ok && cancel) cancel.onPress();
  };
}
