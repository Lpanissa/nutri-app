import { Alert } from 'react-native';

// Troca o Alert.alert padrão do Android/navegador pelo pop-up do app (ver Dialogo.tsx).
export type DlgButton = { text?: string; style?: 'default' | 'cancel' | 'destructive'; onPress?: () => void };
export type Dlg = { title: string; message?: string; buttons: DlgButton[] };

let listener: ((d: Dlg) => void) | null = null;

export function onDialog(fn: (d: Dlg) => void) {
  listener = fn;
  return () => {
    if (listener === fn) listener = null;
  };
}

const original = Alert.alert.bind(Alert);

(Alert as any).alert = (title: string, message?: string, buttons?: DlgButton[]) => {
  const d: Dlg = {
    title: String(title || ''),
    message: message ? String(message) : undefined,
    buttons: buttons && buttons.length ? buttons : [{ text: 'OK' }],
  };
  if (listener) listener(d);
  else original(title, message, buttons as any);
};
