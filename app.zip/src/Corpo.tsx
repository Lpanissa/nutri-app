import React, { useState } from 'react';
import { View, Text, ScrollView, Alert } from 'react-native';
import { C } from './theme';
import { Body } from './types';
import { Store, todayStr } from './storage';
import { Card, Btn, Input, H } from './ui';

function num(t: string): number | undefined {
  const v = parseFloat(t.replace(',', '.'));
  return isNaN(v) ? undefined : v;
}

function Bars({ data, color }: { data: { label: string; v: number }[]; color: string }) {
  if (data.length === 0) return <Text style={{ color: C.muted }}>Sem registros ainda.</Text>;
  const max = Math.max(...data.map((d) => d.v));
  const min = Math.min(...data.map((d) => d.v));
  const span = max - min || 1;
  return (
    <View style={{ flexDirection: 'row', alignItems: 'flex-end', height: 110, marginTop: 6 }}>
      {data.slice(-12).map((d, i) => (
        <View key={i} style={{ flex: 1, alignItems: 'center' }}>
          <Text style={{ fontSize: 9, color: C.muted }}>{d.v}</Text>
          <View style={{ width: 14, height: 20 + ((d.v - min) / span) * 60, backgroundColor: color, borderRadius: 4, marginTop: 2 }} />
          <Text style={{ fontSize: 9, color: C.muted }}>{d.label}</Text>
        </View>
      ))}
    </View>
  );
}

export default function Corpo({ body, setBody }: { body: Body[]; setBody: (b: Body[]) => void }) {
  const [peso, setPeso] = useState('');
  const [magra, setMagra] = useState('');
  const [gorda, setGorda] = useState('');

  function salvar() {
    const p = num(peso), m = num(magra), g = num(gorda);
    if (p === undefined && m === undefined && g === undefined) return Alert.alert('Preencha pelo menos um valor');
    const date = todayStr();
    const entry: Body = { id: String(Date.now()), date, peso: p, magra: m, gorda: g };
    const next = [...body.filter((b) => b.date !== date), entry].sort((a, b) => a.date.localeCompare(b.date));
    setBody(next);
    Store.saveBody(next);
    setPeso(''); setMagra(''); setGorda('');
  }
  function apagar(id: string) {
    const n = body.filter((b) => b.id !== id);
    setBody(n);
    Store.saveBody(n);
  }

  const lab = (b: Body) => b.date.slice(8, 10) + '/' + b.date.slice(5, 7);
  const serie = (k: 'peso' | 'magra' | 'gorda') => body.filter((b) => b[k] !== undefined).map((b) => ({ label: lab(b), v: b[k] as number }));

  return (
    <ScrollView contentContainerStyle={{ padding: 16 }}>
      <H>Meu corpo</H>
      <Card>
        <Text style={{ fontWeight: '600', color: C.text }}>Registrar hoje</Text>
        <Input placeholder="Peso (kg)" decimal value={peso} onChangeText={setPeso} />
        <Input placeholder="Massa magra (kg)" decimal value={magra} onChangeText={setMagra} />
        <Input placeholder="Massa gorda (kg)" decimal value={gorda} onChangeText={setGorda} />
        <Btn title="Salvar" onPress={salvar} />
      </Card>
      <Card><Text style={{ fontWeight: '600', color: C.text }}>Peso (kg)</Text><Bars data={serie('peso')} color={C.green} /></Card>
      <Card><Text style={{ fontWeight: '600', color: C.text }}>Massa magra (kg)</Text><Bars data={serie('magra')} color="#3B82C4" /></Card>
      <Card><Text style={{ fontWeight: '600', color: C.text }}>Massa gorda (kg)</Text><Bars data={serie('gorda')} color={C.amber} /></Card>
      <Card>
        <Text style={{ fontWeight: '600', color: C.text, marginBottom: 6 }}>Histórico</Text>
        {body.length === 0 && <Text style={{ color: C.muted }}>Nada registrado ainda.</Text>}
        {[...body].reverse().map((b) => (
          <View key={b.id} style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 6, borderBottomWidth: 1, borderColor: C.line }}>
            <Text style={{ flex: 1, color: C.text }}>
              {b.date.split('-').reverse().join('/')}  ·  {b.peso ?? '-'} kg  ·  magra {b.magra ?? '-'}  ·  gorda {b.gorda ?? '-'}
            </Text>
            <Text onPress={() => apagar(b.id)} style={{ color: C.warn, fontWeight: '600' }}>apagar</Text>
          </View>
        ))}
      </Card>
    </ScrollView>
  );
}
