import AsyncStorage from '@react-native-async-storage/async-storage';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { db } from './firebase';
import { Meal, Body, Recipe } from './types';

export const DEFAULT_URL = 'https://assistente-panissa.lpanissa.workers.dev';

export type Profile = { nome: string; foto?: string; idade?: string; altura?: string; meta?: string; objetivo?: string };

let uid = '';
export function setUser(u: string) { uid = u; }

async function load<T>(name: string, def: T): Promise<T> {
  const key = uid + ':' + name;
  try {
    const snap = await getDoc(doc(db, 'users', uid, 'data', name));
    if (snap.exists()) {
      const v = JSON.parse(snap.data().json as string) as T;
      try { await AsyncStorage.setItem(key, JSON.stringify(v)); } catch {}
      return v;
    }
  } catch {}
  try {
    const v = await AsyncStorage.getItem(key);
    return v ? (JSON.parse(v) as T) : def;
  } catch {
    return def;
  }
}

async function save(name: string, value: unknown) {
  const key = uid + ':' + name;
  try { await AsyncStorage.setItem(key, JSON.stringify(value)); } catch {}
  try {
    let v: any = value;
    if (name === 'meals' && Array.isArray(v)) v = v.map((m: any) => ({ ...m, uri: undefined }));
    await setDoc(doc(db, 'users', uid, 'data', name), { json: JSON.stringify(v), updated: Date.now() });
  } catch {}
}

export const Store = {
  meals: () => load<Meal[]>('meals', []),
  saveMeals: (m: Meal[]) => save('meals', m),
  body: () => load<Body[]>('body', []),
  saveBody: (b: Body[]) => save('body', b),
  recipes: () => load<Recipe[]>('recipes', []),
  saveRecipes: (r: Recipe[]) => save('recipes', r),
  profile: (def: Profile) => load<Profile>('profile', def),
  saveProfile: (p: Profile) => save('profile', p),
};

export function todayStr(d = new Date()): string {
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${d.getFullYear()}-${m}-${day}`;
}
