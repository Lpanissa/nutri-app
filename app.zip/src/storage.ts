import AsyncStorage from '@react-native-async-storage/async-storage';
import { doc, getDoc, setDoc, deleteDoc } from 'firebase/firestore';
import { db } from './firebase';
import { Meal, Body, Recipe, Falha } from './types';

export const DEFAULT_URL = 'https://assistente-panissa.lpanissa.workers.dev';

export type Profile = { nome: string; foto?: string; idade?: string; altura?: string; meta?: string; objetivo?: string };

let uid = '';
export function setUser(u: string) { uid = u; }
export function getUser() { return uid; }

function strip(name: string, value: unknown) {
  let v: any = value;
  if (name === 'meals' && Array.isArray(v)) v = v.map((m: any) => ({ ...m, uri: undefined }));
  return JSON.stringify(v);
}

// Carrega do celular e da nuvem e fica com o mais recente (pelo horário da última gravação).
// Se o celular tem algo mais novo (ex.: gravou sem internet), manda para a nuvem.
async function load<T>(u: string, name: string, def: T): Promise<T> {
  const key = u + ':' + name;
  let local: T | undefined;
  let localTs = 0;
  try {
    const raw = await AsyncStorage.getItem(key);
    if (raw) local = JSON.parse(raw) as T;
    localTs = parseInt((await AsyncStorage.getItem(key + ':t')) || '0', 10) || 0;
  } catch {}
  try {
    const snap = await getDoc(doc(db, 'users', u, 'data', name));
    if (snap.exists()) {
      const cloudTs = Number(snap.data().updated) || 0;
      if (local !== undefined && localTs > cloudTs) {
        try { await setDoc(doc(db, 'users', u, 'data', name), { json: strip(name, local), updated: localTs }); } catch {}
        return local;
      }
      const v = JSON.parse(snap.data().json as string) as T;
      try {
        await AsyncStorage.setItem(key, JSON.stringify(v));
        await AsyncStorage.setItem(key + ':t', String(cloudTs));
      } catch {}
      return v;
    }
  } catch {}
  return local !== undefined ? local : def;
}

async function save(u: string, name: string, value: unknown) {
  if (!u) return;
  const key = u + ':' + name;
  const ts = Date.now();
  try {
    await AsyncStorage.setItem(key, JSON.stringify(value));
    await AsyncStorage.setItem(key + ':t', String(ts));
  } catch {}
  try {
    await setDoc(doc(db, 'users', u, 'data', name), { json: strip(name, value), updated: ts });
  } catch {}
}

// Apaga tudo da conta (celular e nuvem). Usado em "Excluir minha conta".
export async function apagarTudo(u: string) {
  const nomes = ['meals', 'falhas', 'body', 'recipes', 'profile'];
  for (const n of nomes) {
    try { await deleteDoc(doc(db, 'users', u, 'data', n)); } catch {}
    try { await AsyncStorage.multiRemove([u + ':' + n, u + ':' + n + ':t']); } catch {}
  }
}

// Cada tela pode pegar um Store "preso" a uma conta; assim uma análise que termina
// depois de trocar de conta grava na conta certa.
export function storeFor(u: string) {
  return {
    meals: () => load<Meal[]>(u, 'meals', []),
    saveMeals: (m: Meal[]) => save(u, 'meals', m),
    falhas: () => load<Falha[]>(u, 'falhas', []),
    saveFalhas: (f: Falha[]) => save(u, 'falhas', f),
    body: () => load<Body[]>(u, 'body', []),
    saveBody: (b: Body[]) => save(u, 'body', b),
    recipes: () => load<Recipe[]>(u, 'recipes', []),
    saveRecipes: (r: Recipe[]) => save(u, 'recipes', r),
    profile: (def: Profile) => load<Profile>(u, 'profile', def),
    saveProfile: (p: Profile) => save(u, 'profile', p),
  };
}

// Atalho para as telas: usa a conta atual no momento da chamada.
export const Store = {
  meals: () => storeFor(uid).meals(),
  saveMeals: (m: Meal[]) => storeFor(uid).saveMeals(m),
  falhas: () => storeFor(uid).falhas(),
  saveFalhas: (f: Falha[]) => storeFor(uid).saveFalhas(f),
  body: () => storeFor(uid).body(),
  saveBody: (b: Body[]) => storeFor(uid).saveBody(b),
  recipes: () => storeFor(uid).recipes(),
  saveRecipes: (r: Recipe[]) => storeFor(uid).saveRecipes(r),
  profile: (def: Profile) => storeFor(uid).profile(def),
  saveProfile: (p: Profile) => storeFor(uid).saveProfile(p),
};

export function todayStr(d = new Date()): string {
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${d.getFullYear()}-${m}-${day}`;
}
