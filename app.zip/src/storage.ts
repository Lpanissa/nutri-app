import AsyncStorage from '@react-native-async-storage/async-storage';
import { Meal, Body, Recipe } from './types';

async function load<T>(key: string, def: T): Promise<T> {
  try {
    const v = await AsyncStorage.getItem(key);
    return v ? (JSON.parse(v) as T) : def;
  } catch {
    return def;
  }
}
async function save(key: string, value: unknown) {
  try {
    await AsyncStorage.setItem(key, JSON.stringify(value));
  } catch {}
}

export const DEFAULT_URL = 'https://assistente-panissa.lpanissa.workers.dev';

export const Store = {
  meals: () => load<Meal[]>('meals', []),
  saveMeals: (m: Meal[]) => save('meals', m),
  body: () => load<Body[]>('body', []),
  saveBody: (b: Body[]) => save('body', b),
  recipes: () => load<Recipe[]>('recipes', []),
  saveRecipes: (r: Recipe[]) => save('recipes', r),
  settings: () => load<{ url: string; key: string }>('settings', { url: DEFAULT_URL, key: '' }),
  saveSettings: (s: { url: string; key: string }) => save('settings', s),
};

export function todayStr(d = new Date()): string {
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${d.getFullYear()}-${m}-${day}`;
}
