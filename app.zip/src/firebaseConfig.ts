export const firebaseConfig = {
  apiKey: 'AIzaSyAlAuwNMNqL7cc0_GcUrM4WNfmm3cH6bls',
  authDomain: 'mavie-e973b.firebaseapp.com',
  projectId: 'mavie-e973b',
  storageBucket: 'mavie-e973b.firebasestorage.app',
  messagingSenderId: '277943751026',
  appId: '1:277943751026:web:d1204a6698c3e8d36d8deb',
};
