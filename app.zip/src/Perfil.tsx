import React, { useState } from 'react';
import { View, Text, Image, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { C } from './theme';
import { Store, Profile } from './storage';
import { Card, Btn, Input, H } from './ui';

export function Avatar({ p, size = 44 }: { p: Profile; size?: number }) {
  if (p.foto) return <Image source={{ uri: p.foto }} style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: C.greenLight }} />;
  const ini = (p.nome || '?').trim().charAt(0).toUpperCase();
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: C.green, alignItems: 'center', justifyContent: 'center' }}>
      <Text style={{ color: '#fff', fontWeight: '700', fontSize: size * 0.42 }}>{ini}</Text>
    </View>
  );
}

export default function Perfil({ profile, email, onSave, onClose, onLogout }: { profile: Profile; email: string; onSave: (p: Profile) => void; onClose: () => void; onLogout: () => void }) {
  const [p, setP] = useState<Profile>(profile);
  const set = (k: keyof Profile) => (v: string) => setP({ ...p, [k]: v });

  async function trocarFoto() {
    const r = await ImagePicker.launchImageLibraryAsync({ quality: 0.3, base64: true, allowsEditing: true, aspect: [1, 1] });
    if (r.canceled || !r.assets || !r.assets[0] || !r.assets[0].base64) return;
    const a = r.assets[0];
    setP({ ...p, foto: 'data:' + (a.mimeType || 'image/jpeg') + ';base64,' + a.base64 });
  }

  async function salvar() {
    const n = { ...p, nome: (p.nome || '').trim() || 'Você' };
    await Store.saveProfile(n);
    onSave(n);
    onClose();
  }

  return (
    <View style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: C.bg }}>
      <ScrollView contentContainerStyle={{ padding: 16, paddingTop: 48, maxWidth: 560, width: '100%', alignSelf: 'center' }} keyboardShouldPersistTaps="handled">
        <TouchableOpacity onPress={onClose} style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 12 }}>
          <Ionicons name="chevron-back" size={24} color={C.green} />
          <Text style={{ color: C.green, fontWeight: '600', fontSize: 16 }}>Voltar</Text>
        </TouchableOpacity>
        <H>Meu perfil</H>
        <Card>
          <View style={{ alignItems: 'center', marginBottom: 8 }}>
            <TouchableOpacity onPress={trocarFoto}>
              <Avatar p={p} size={104} />
              <View style={{ position: 'absolute', right: 0, bottom: 0, backgroundColor: C.green, borderRadius: 16, padding: 7 }}>
                <Ionicons name="camera" size={16} color="#fff" />
              </View>
            </TouchableOpacity>
            <Text style={{ color: C.muted, marginTop: 8 }}>{email}</Text>
          </View>
          <Text style={{ color: C.muted, marginTop: 6 }}>Nome</Text>
          <Input value={p.nome} onChangeText={set('nome')} placeholder="Como quer ser chamada(o)" />
          <Text style={{ color: C.muted, marginTop: 6 }}>Idade</Text>
          <Input value={p.idade || ''} onChangeText={set('idade')} keyboardType="numeric" placeholder="Ex.: 30" />
          <Text style={{ color: C.muted, marginTop: 6 }}>Altura (cm)</Text>
          <Input value={p.altura || ''} onChangeText={set('altura')} keyboardType="numeric" placeholder="Ex.: 165" />
          <Text style={{ color: C.muted, marginTop: 6 }}>Meta de calorias por dia</Text>
          <Input value={p.meta || ''} onChangeText={set('meta')} keyboardType="numeric" placeholder="Ex.: 1800" />
          <Text style={{ color: C.muted, marginTop: 6 }}>Objetivo</Text>
          <Input value={p.objetivo || ''} onChangeText={set('objetivo')} placeholder="Ex.: emagrecer, ganhar massa, comer melhor" />
          <Btn title="Salvar perfil" icon="checkmark" onPress={salvar} />
        </Card>
        <Btn title="Sair da conta" icon="log-out-outline" kind="danger" onPress={() => Alert.alert('Sair da conta?', '', [{ text: 'Não', style: 'cancel' }, { text: 'Sair', style: 'destructive', onPress: onLogout }])} />
      </ScrollView>
    </View>
  );
}
