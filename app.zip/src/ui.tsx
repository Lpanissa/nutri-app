import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, TextInput, TextInputProps } from 'react-native';
import { C } from './theme';
import { Total } from './types';

export const Card = ({ children, style }: { children: React.ReactNode; style?: any }) => (
  <View style={[s.card, style]}>{children}</View>
);

export const Btn = ({ title, onPress, kind = 'primary', disabled }: { title: string; onPress: () => void; kind?: 'primary' | 'ghost' | 'danger'; disabled?: boolean }) => (
  <TouchableOpacity
    onPress={onPress}
    disabled={disabled}
    style={[s.btn, kind === 'ghost' && s.btnGhost, kind === 'danger' && s.btnDanger, disabled && { opacity: 0.5 }]}
  >
    <Text style={[s.btnText, kind === 'ghost' && { color: C.green }, kind === 'danger' && { color: C.warn }]}>{title}</Text>
  </TouchableOpacity>
);

export const Chip = ({ title, active, onPress }: { title: string; active: boolean; onPress: () => void }) => (
  <TouchableOpacity onPress={onPress} style={[s.chip, active && s.chipOn]}>
    <Text style={[s.chipText, active && { color: '#fff' }]}>{title}</Text>
  </TouchableOpacity>
);

export const Input = (p: TextInputProps) => (
  <TextInput placeholderTextColor={C.muted} {...p} style={[s.input, p.style]} />
);

export const H = ({ children }: { children: React.ReactNode }) => <Text style={s.h}>{children}</Text>;

export const Macros = ({ t }: { t: Total }) => (
  <View style={s.macros}>
    <Mac label="kcal" v={t.kcal} big />
    <Mac label="proteína" v={t.proteina} unit="g" />
    <Mac label="carbo" v={t.carbo} unit="g" />
    <Mac label="gordura" v={t.gordura} unit="g" />
  </View>
);
const Mac = ({ label, v, unit, big }: { label: string; v: number; unit?: string; big?: boolean }) => (
  <View style={{ alignItems: 'center', flex: 1 }}>
    <Text style={[s.macV, big && { fontSize: 22 }]}>{Math.round(v || 0)}{unit || ''}</Text>
    <Text style={s.macL}>{label}</Text>
  </View>
);

export function sum(list: { total: Total }[]): Total {
  return list.reduce(
    (a, m) => ({
      kcal: a.kcal + (m.total?.kcal || 0),
      proteina: a.proteina + (m.total?.proteina || 0),
      carbo: a.carbo + (m.total?.carbo || 0),
      gordura: a.gordura + (m.total?.gordura || 0),
    }),
    { kcal: 0, proteina: 0, carbo: 0, gordura: 0 }
  );
}

export const s = StyleSheet.create({
  card: { backgroundColor: C.card, borderRadius: 18, padding: 16, marginBottom: 14, borderWidth: 1, borderColor: C.line },
  btn: { backgroundColor: C.green, paddingVertical: 13, paddingHorizontal: 16, borderRadius: 12, alignItems: 'center', marginVertical: 4 },
  btnGhost: { backgroundColor: C.greenLight },
  btnDanger: { backgroundColor: '#F7ECE8' },
  btnText: { color: '#fff', fontWeight: '600', fontSize: 15, letterSpacing: 0.3 },
  chip: { paddingVertical: 8, paddingHorizontal: 14, borderRadius: 20, backgroundColor: C.greenLight, marginRight: 8, marginBottom: 8 },
  chipOn: { backgroundColor: C.green },
  chipText: { color: C.green, fontWeight: '500' },
  input: { borderWidth: 1, borderColor: C.line, borderRadius: 12, padding: 12, backgroundColor: '#fff', color: C.text, marginVertical: 4, fontSize: 15 },
  h: { fontSize: 26, fontWeight: '300', color: C.text, marginBottom: 14, letterSpacing: 0.3 },
  macros: { flexDirection: 'row', marginTop: 8 },
  macV: { fontSize: 16, fontWeight: '600', color: C.green },
  macL: { fontSize: 11, color: C.muted, letterSpacing: 0.4 },
});
