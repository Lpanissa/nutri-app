import { Platform } from 'react-native';
import { BUILD, VERSAO, CANAL } from './version';

export type Upd = { build: number; versao: string; url: string };
export const BUILD_ATUAL = BUILD;
export const VERSAO_ATUAL = VERSAO;

const API = 'https://api.github.com/repos/Lpanissa/nutri-app/releases/tags/v3';
const PAGINA = 'https://github.com/Lpanissa/nutri-app/releases/tag/v3';

// Olha no GitHub se existe uma versão mais nova que a instalada (só no app do celular).
export async function checarAtualizacao(): Promise<{ ok: boolean; upd: Upd | null }> {
  if (Platform.OS === 'web' || CANAL === 'play') return { ok: true, upd: null };
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 10000);
  try {
    const r = await fetch(API, { headers: { Accept: 'application/vnd.github+json' }, signal: ctrl.signal });
    if (!r.ok) return { ok: false, upd: null };
    const j = await r.json();
    const m = /build:(\d+)/.exec(String((j && j.body) || ''));
    const novo = m ? parseInt(m[1], 10) : 0;
    if (!novo || novo <= BUILD) return { ok: true, upd: null };
    const v = /versao:(\d+\.\d+\.\d+)/.exec(String((j && j.body) || ''));
    const apk = ((j && j.assets) || []).find((a: any) => /\.apk$/i.test(String(a.name)));
    return { ok: true, upd: { build: novo, versao: v ? v[1] : '1.1.' + novo, url: apk ? apk.browser_download_url : PAGINA } };
  } catch {
    return { ok: false, upd: null };
  } finally {
    clearTimeout(timer);
  }
}
