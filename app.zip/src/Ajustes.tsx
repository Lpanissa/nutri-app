import React from 'react';
import { Text, ScrollView } from 'react-native';
import { C } from './theme';
import { Card, Btn, H } from './ui';

export default function Ajustes({ email, onPerfil, onLogout }: { email: string; onPerfil: () => void; onLogout: () => void }) {
  return (
    <ScrollView contentContainerStyle={{ padding: 16 }}>
      <H>Conta</H>
      <Card>
        <Text style={{ color: C.muted }}>Você está conectada(o) como</Text>
        <Text style={{ color: C.text, fontWeight: '600', fontSize: 16, marginTop: 2 }}>{email}</Text>
        <Btn title="Editar meu perfil" icon="person" kind="ghost" onPress={onPerfil} />
        <Btn title="Sair da conta" icon="log-out-outline" kind="danger" onPress={onLogout} />
      </Card>
      <Text style={{ color: C.muted, fontSize: 12 }}>Seus dados (refeições, peso, receitas e perfil) ficam guardados na sua conta e acompanham você em qualquer aparelho.</Text>
    </ScrollView>
  );
}
