import React, { useEffect, useState } from 'react';
import { Text, ScrollView, Alert } from 'react-native';
import { C } from './theme';
import { Store, DEFAULT_URL } from './storage';
import { Card, Btn, Input, H } from './ui';

export default function Ajustes() {
  const [url, setUrl] = useState(DEFAULT_URL);
  const [key, setKey] = useState('');
  useEffect(() => { Store.settings().then((s) => { setUrl(s.url || DEFAULT_URL); setKey(s.key || ''); }); }, []);
  async function salvar() {
    await Store.saveSettings({ url: url.trim(), key: key.trim() });
    Alert.alert('Salvo');
  }
  return (
    <ScrollView contentContainerStyle={{ padding: 16 }}>
      <H>Ajustes</H>
      <Card>
        <Text style={{ color: C.muted }}>Endereço do servidor</Text>
        <Input value={url} onChangeText={setUrl} autoCapitalize="none" autoCorrect={false} />
        <Text style={{ color: C.muted, marginTop: 8 }}>Senha do servidor (a mesma do app Assistente Panissa)</Text>
        <Input value={key} onChangeText={setKey} autoCapitalize="none" autoCorrect={false} secureTextEntry />
        <Btn title="Salvar" onPress={salvar} />
      </Card>
      <Text style={{ color: C.muted, fontSize: 12 }}>Os seus dados (refeições, peso e receitas) ficam guardados só neste celular.</Text>
    </ScrollView>
  );
}
