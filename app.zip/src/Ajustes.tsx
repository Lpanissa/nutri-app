import React, { useState } from 'react';
import { Text, ScrollView, Alert, ActivityIndicator } from 'react-native';
import { C } from './theme';
import { Card, Btn, H, Input } from './ui';
import { auth, FA } from './firebase';
import { apagarTudo } from './storage';

export default function Ajustes({ email, onPerfil, onPrivacidade, onLogout }: { email: string; onPerfil: () => void; onPrivacidade: () => void; onLogout: () => void }) {
  const [excluindo, setExcluindo] = useState(false);
  const [senha, setSenha] = useState('');
  const [ocupado, setOcupado] = useState(false);

  const user = auth.currentUser;
  const temSenha = !!user && user.providerData.some((p) => p.providerId === 'password');

  function pedirExclusao() {
    Alert.alert(
      'Excluir minha conta?',
      'Isso apaga para sempre sua conta e todos os seus registros (refeições, peso, receitas e perfil). Não dá para desfazer.',
      [{ text: 'Cancelar', style: 'cancel' }, { text: 'Continuar', style: 'destructive', onPress: () => setExcluindo(true) }]
    );
  }

  async function excluir() {
    const u = auth.currentUser;
    if (!u) return;
    if (temSenha && !senha) return Alert.alert('Digite sua senha para confirmar');
    setOcupado(true);
    try {
      if (temSenha && u.email) {
        await FA.reauthenticateWithCredential(u, FA.EmailAuthProvider.credential(u.email, senha));
      }
      await apagarTudo(u.uid);
      await FA.deleteUser(u);
    } catch (e: any) {
      setOcupado(false);
      const code = String((e && e.code) || '');
      if (code.includes('wrong-password') || code.includes('invalid-credential')) Alert.alert('Senha incorreta', 'Confira a senha e tente de novo.');
      else if (code.includes('requires-recent-login')) Alert.alert('Entre de novo', 'Por segurança, saia da conta, entre outra vez e tente excluir logo em seguida.');
      else Alert.alert('Não consegui excluir agora', 'Veja a internet e tente de novo.');
    }
  }

  return (
    <ScrollView contentContainerStyle={{ padding: 16 }} keyboardShouldPersistTaps="handled">
      <H>Conta</H>
      <Card>
        <Text style={{ color: C.muted }}>Você está conectada(o) como</Text>
        <Text style={{ color: C.text, fontWeight: '600', fontSize: 16, marginTop: 2 }}>{email}</Text>
        <Btn title="Editar meu perfil" icon="person" kind="ghost" onPress={onPerfil} />
        <Btn title="Política de privacidade" icon="shield-checkmark-outline" kind="ghost" onPress={onPrivacidade} />
        <Btn title="Sair da conta" icon="log-out-outline" kind="danger" onPress={onLogout} />
      </Card>
      <Card>
        <Text style={{ fontWeight: '600', color: C.text }}>Excluir minha conta</Text>
        <Text style={{ color: C.muted, marginTop: 4 }}>Apaga sua conta e todos os seus dados do app e dos nossos servidores.</Text>
        {!excluindo ? (
          <Btn title="Excluir minha conta" icon="trash-outline" kind="danger" onPress={pedirExclusao} />
        ) : (
          <>
            {temSenha && (
              <>
                <Text style={{ color: C.muted, marginTop: 10 }}>Digite sua senha para confirmar</Text>
                <Input value={senha} onChangeText={setSenha} secureTextEntry placeholder="Senha" autoCapitalize="none" />
              </>
            )}
            {ocupado ? (
              <ActivityIndicator color={C.green} style={{ marginTop: 12 }} />
            ) : (
              <>
                <Btn title="Excluir para sempre" icon="trash" kind="danger" onPress={excluir} />
                <Btn title="Cancelar" kind="ghost" onPress={() => { setExcluindo(false); setSenha(''); }} />
              </>
            )}
          </>
        )}
      </Card>
      <Text style={{ color: C.muted, fontSize: 12 }}>Seus dados (refeições, peso, receitas e perfil) ficam guardados na sua conta e acompanham você em qualquer aparelho.</Text>
    </ScrollView>
  );
}
