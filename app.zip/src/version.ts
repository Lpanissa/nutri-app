// Versão do app: MAIOR.MENOR.BUILD
//  MAIOR: muda quando o app inteiro muda de cara/jeito.
//  MENOR: sobe quando muda algo que aparece na interface.
//  BUILD: número do build, sobe sozinho a cada versão gerada (o GitHub troca o 0 abaixo; ver .github/workflows/build.yml).
export const MAJOR = 1;
export const MINOR = 1;
export const BUILD = 0;
export const VERSAO = MAJOR + '.' + MINOR + '.' + BUILD;
// Canal de distribuição: 'apk' (baixado do GitHub, se atualiza sozinho) ou 'play' (Google Play, atualiza pela loja).
// O GitHub troca 'apk' por 'play' ao gerar o pacote da loja (ver .github/workflows/build.yml).
export const CANAL: string = 'apk';
