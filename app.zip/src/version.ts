// Número da versão instalada. O GitHub troca este valor a cada build (ver .github/workflows/build.yml).
export const BUILD = 0;
