export const PRIV: [string, string][] = [
 [
  "Quem somos",
  "O Mavité é um aplicativo de acompanhamento de alimentação. Esta política explica quais dados coletamos, para que usamos e quais são os seus direitos, conforme a Lei Geral de Proteção de Dados (LGPD)."
 ],
 [
  "Dados que coletamos",
  "Dados da conta: e-mail e senha (a senha é guardada de forma protegida pelo serviço de login do Google/Firebase; nós nunca a vemos) ou dados básicos do login com Google (nome, e-mail e foto).\nDados do perfil que você escolher preencher: nome, foto, idade, altura, meta de calorias e objetivo.\nDados de uso: refeições registradas (tipo, data, itens e valores nutricionais estimados), peso e medidas corporais, e receitas que você salvar.\nFotos de refeições: a foto é enviada para análise no momento em que você pede o cálculo."
 ],
 [
  "Para que usamos",
  "Para fazer o aplicativo funcionar: entrar na sua conta, guardar o seu histórico, mostrar seus resultados e estimar as informações nutricionais das suas refeições. Não usamos seus dados para publicidade e não vendemos seus dados."
 ],
 [
  "Inteligência artificial",
  "Para estimar calorias e nutrientes, a foto ou o texto da refeição é enviado a um serviço de inteligência artificial (Anthropic - Claude) por meio do nosso servidor. O envio serve só para gerar a resposta. As estimativas são aproximadas e não substituem orientação de nutricionista ou médico."
 ],
 [
  "Onde os dados ficam",
  "Os dados da conta e do histórico ficam guardados em serviços do Google (Firebase Authentication e Cloud Firestore), vinculados à sua conta. Cada pessoa só consegue acessar os próprios dados. Também mantemos uma cópia no seu aparelho para o app funcionar mais rápido."
 ],
 [
  "Compartilhamento",
  "Só compartilhamos dados com os prestadores necessários para o app funcionar (Google/Firebase, Cloudflare e o serviço de inteligência artificial), ou quando a lei exigir."
 ],
 [
  "Seus direitos",
  "Você pode, a qualquer momento: ver e corrigir seus dados no próprio app (aba Conta e perfil), pedir a exclusão da sua conta e de todos os seus dados, e pedir informações sobre o tratamento dos seus dados. Para isso, fale com a gente pelo contato abaixo."
 ],
 [
  "Segurança e crianças",
  "Usamos conexão segura (HTTPS) e regras de acesso por conta. O app não é destinado a menores de 13 anos."
 ],
 [
  "Mudanças",
  "Podemos atualizar esta política. Quando houver mudanças importantes, avisaremos no app. Última atualização: outubro de 2026."
 ],
 [
  "Contato",
  "Dúvidas ou pedidos sobre seus dados: lpanissa@gmail.com"
 ]
];
