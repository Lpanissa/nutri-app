export type Item = { nome: string; porcao: string; kcal: number; proteina: number; carbo: number; gordura: number };
export type Total = { kcal: number; proteina: number; carbo: number; gordura: number };
export type Meal = { id: string; date: string; tipo: string; itens: Item[]; total: Total; obs?: string; uri?: string; ts: number };
export type Body = { id: string; date: string; peso?: number; magra?: number; gorda?: number };
export type Recipe = { id: string; titulo: string; texto: string };

export const MEAL_TYPES = [
  'Café da manhã', 'Lanche da manhã', 'Doce isolado', 'Almoço',
  'Sobremesa', 'Lanche da tarde', 'Ceia', 'Janta',
];
