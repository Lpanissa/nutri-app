export const C = {
  bg: '#FAFBF8', card: '#FFFFFF', green: '#4A7C59', greenLight: '#EEF3EC',
  text: '#26332B', muted: '#78857B', line: '#E6EBE4', warn: '#B5654A', amber: '#C9A24B',
};
