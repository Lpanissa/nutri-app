import React, { useState } from 'react';
import { View, Text, Image, ScrollView, TouchableOpacity, Platform, ActivityIndicator, KeyboardAvoidingView } from 'react-native';
import { C } from './theme';
import { auth, FA, erroBonito } from './firebase';
import { Btn, Input } from './ui';

export default function Auth() {
  const [modo, setModo] = useState<'entrar' | 'cadastrar'>('entrar');
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [conf, setConf] = useState('');
  const [erro, setErro] = useState('');
  const [busy, setBusy] = useState(false);
  const cad = modo === 'cadastrar';

  async function enviar() {
    setErro('');
    const em = email.trim();
    if (!em || !senha) return setErro('Preencha o e-mail e a senha.');
    if (cad) {
      if (senha.length < 6) return setErro('A senha precisa ter pelo menos 6 caracteres.');
      if (senha !== conf) return setErro('As senhas não são iguais. Confira e digite de novo.');
    }
    setBusy(true);
    try {
      if (cad) await FA.createUserWithEmailAndPassword(auth, em, senha);
      else await FA.signInWithEmailAndPassword(auth, em, senha);
    } catch (e) {
      setErro(erroBonito(e));
    } finally {
      setBusy(false);
    }
  }

  async function google() {
    setErro('');
    if (Platform.OS !== 'web') return setErro('O login com Google funciona na versão do navegador (mavite.pages.dev). Aqui no app, use e-mail e senha.');
    setBusy(true);
    try {
      await FA.signInWithPopup(auth, new FA.GoogleAuthProvider());
    } catch (e) {
      setErro(erroBonito(e));
    } finally {
      setBusy(false);
    }
  }

  async function esqueci() {
    setErro('');
    if (!email.trim()) return setErro('Digite seu e-mail acima para receber o link de nova senha.');
    try {
      await FA.sendPasswordResetEmail(auth, email.trim());
      setErro('Enviamos um link para o seu e-mail para criar uma nova senha.');
    } catch (e) {
      setErro(erroBonito(e));
    }
  }

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: C.bg }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', padding: 24, maxWidth: 460, width: '100%', alignSelf: 'center' }} keyboardShouldPersistTaps="handled">
        <View style={{ alignItems: 'center', marginBottom: 24 }}>
          <View style={{ width: 84, height: 84, borderRadius: 26, backgroundColor: C.green, alignItems: 'center', justifyContent: 'center' }}>
            <Image source={require('../assets/splash-icon.png')} style={{ width: 60, height: 60 }} />
          </View>
          <Text style={{ fontSize: 30, fontWeight: '800', color: C.text, marginTop: 14 }}>Mavité</Text>
          <Text style={{ color: C.muted, marginTop: 4 }}>comer bem, viver melhor</Text>
        </View>

        <View style={{ flexDirection: 'row', backgroundColor: C.greenLight, borderRadius: 16, padding: 4, marginBottom: 14 }}>
          {(['entrar', 'cadastrar'] as const).map((m) => (
            <TouchableOpacity key={m} onPress={() => { setModo(m); setErro(''); }} style={{ flex: 1, paddingVertical: 11, borderRadius: 12, alignItems: 'center', backgroundColor: modo === m ? C.green : 'transparent' }}>
              <Text style={{ fontWeight: '600', color: modo === m ? '#fff' : C.green }}>{m === 'entrar' ? 'Entrar' : 'Criar conta'}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <Input placeholder="E-mail" value={email} onChangeText={setEmail} autoCapitalize="none" autoCorrect={false} keyboardType="email-address" />
        <Input placeholder="Senha" value={senha} onChangeText={setSenha} secureTextEntry autoCapitalize="none" />
        {cad && <Input placeholder="Confirmar senha" value={conf} onChangeText={setConf} secureTextEntry autoCapitalize="none" />}
        {cad && conf.length > 0 && senha !== conf ? <Text style={{ color: C.warn, marginTop: 4 }}>As senhas ainda não são iguais.</Text> : null}
        {erro ? <Text style={{ color: erro.startsWith('Enviamos') ? C.green : C.warn, marginVertical: 8 }}>{erro}</Text> : null}

        {busy ? <ActivityIndicator color={C.green} style={{ marginVertical: 16 }} /> : (
          <View style={{ marginTop: 8 }}>
            <Btn title={cad ? 'Criar minha conta' : 'Entrar'} onPress={enviar} />
            <Btn title="Entrar com o Google" icon="logo-google" kind="ghost" onPress={google} />
            {!cad && (
              <TouchableOpacity onPress={esqueci} style={{ alignItems: 'center', marginTop: 10 }}>
                <Text style={{ color: C.muted }}>Esqueci minha senha</Text>
              </TouchableOpacity>
            )}
          </View>
        )}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
