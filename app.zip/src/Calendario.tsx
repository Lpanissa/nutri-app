import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { C } from './theme';
import { Meal, Falha } from './types';
import { Store, todayStr } from './storage';
import { Card, H, Btn } from './ui';
import Hoje, { DayList } from './Hoje';

const MESES = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
const DIAS = ['D', 'S', 'T', 'Q', 'Q', 'S', 'S'];

export default function Calendario({ meals, setMeals, onAdd, onFail, falhas, onClearFalha, reset }: { meals: Meal[]; setMeals: (m: Meal[]) => void; onAdd: (m: Meal) => void; onFail: (date: string, tipo: string) => void; falhas: Falha[]; onClearFalha: (date: string, tipo: string) => void; reset?: number }) {
  const now = new Date();
  const [ano, setAno] = useState(now.getFullYear());
  const [mes, setMes] = useState(now.getMonth());
  const [sel, setSel] = useState(todayStr());
  const [adding, setAdding] = useState(false);
  const podeAdd = sel <= todayStr();
  // tocar na aba "Agenda" estando nela volta para o calendário
  useEffect(() => { setAdding(false); }, [reset]);

  const primeiro = new Date(ano, mes, 1).getDay();
  const dias = new Date(ano, mes + 1, 0).getDate();
  const cells: (number | null)[] = [];
  for (let i = 0; i < primeiro; i++) cells.push(null);
  for (let d = 1; d <= dias; d++) cells.push(d);
  while (cells.length % 7 !== 0) cells.push(null);

  const kcalDia: Record<string, number> = {};
  meals.forEach((m) => { kcalDia[m.date] = (kcalDia[m.date] || 0) + (m.total?.kcal || 0); });

  function mudar(delta: number) {
    const d = new Date(ano, mes + delta, 1);
    setAno(d.getFullYear());
    setMes(d.getMonth());
  }
  function apagar(id: string) {
    Alert.alert('Apagar refeição?', '', [
      { text: 'Não' },
      { text: 'Apagar', style: 'destructive', onPress: () => { const n = meals.filter((m) => m.id !== id); setMeals(n); Store.saveMeals(n); } },
    ]);
  }

  const rows: (number | null)[][] = [];
  for (let i = 0; i < cells.length; i += 7) rows.push(cells.slice(i, i + 7));

  if (adding) return <Hoje meals={meals} setMeals={setMeals} onAdd={onAdd} onFail={onFail} date={sel} onBack={() => setAdding(false)} />;

  return (
    <ScrollView contentContainerStyle={{ padding: 16 }}>
      <H>Calendário</H>
      <Card>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
          <Btn title="‹" kind="ghost" onPress={() => mudar(-1)} />
          <Text style={{ fontWeight: '600', fontSize: 16, color: C.text }}>{MESES[mes]} {ano}</Text>
          <Btn title="›" kind="ghost" onPress={() => mudar(1)} />
        </View>
        <View style={{ flexDirection: 'row' }}>
          {DIAS.map((d, i) => <Text key={i} style={{ flex: 1, textAlign: 'center', color: C.muted, fontWeight: '600' }}>{d}</Text>)}
        </View>
        {rows.map((r, ri) => (
          <View key={ri} style={{ flexDirection: 'row' }}>
            {r.map((d, ci) => {
              if (!d) return <View key={ci} style={{ flex: 1, height: 52 }} />;
              const ds = `${ano}-${String(mes + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
              const k = kcalDia[ds];
              const on = ds === sel;
              const falhou = falhas.some((f) => f.date === ds);
              return (
                <TouchableOpacity key={ci} onPress={() => { if (on && ds <= todayStr()) setAdding(true); else setSel(ds); }} style={{ flex: 1, height: 52, alignItems: 'center', justifyContent: 'center', borderRadius: 10, backgroundColor: on ? C.green : 'transparent', borderWidth: falhou ? 1 : 0, borderColor: 'rgba(181,101,74,0.6)' }}>
                  <Text style={{ color: on ? '#fff' : C.text, fontWeight: '600' }}>{d}</Text>
                  {k ? <Text style={{ fontSize: 10, color: on ? '#fff' : C.green }}>{Math.round(k)}</Text> : null}
                </TouchableOpacity>
              );
            })}
          </View>
        ))}
      </Card>
      <Text style={{ fontWeight: '600', color: C.text, marginBottom: 8 }}>{sel.split('-').reverse().join('/')}</Text>
      {falhas.filter((f) => f.date === sel).map((f) => (
        <View key={f.tipo} style={{ borderWidth: 1, borderColor: 'rgba(181,101,74,0.45)', borderRadius: 14, padding: 10, marginBottom: 8, flexDirection: 'row', alignItems: 'center' }}>
          <Text style={{ flex: 1, color: C.muted, fontSize: 13 }}>{f.tipo}: a IA não conseguiu ler a foto, então não entrou no cálculo.</Text>
          <TouchableOpacity onPress={() => onClearFalha(f.date, f.tipo)} style={{ paddingLeft: 10 }}><Text style={{ color: C.warn, fontWeight: '600' }}>Limpar</Text></TouchableOpacity>
        </View>
      ))}
      {podeAdd ? <Btn title="Adicionar refeição neste dia" icon="add-circle" onPress={() => setAdding(true)} /> : <Text style={{ color: C.muted, marginBottom: 8 }}>Não dá para registrar refeições em dias futuros.</Text>}
      <DayList date={sel} meals={meals} onDelete={apagar} />
    </ScrollView>
  );
}
