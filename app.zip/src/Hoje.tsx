import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, Image, ActivityIndicator, Alert } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { C } from './theme';
import { Meal, MEAL_TYPES, Item } from './types';
import { Store, todayStr } from './storage';
import { analyzeMeal, Analysis } from './api';
import { Card, Btn, Chip, Input, H, Macros, sum } from './ui';

export function DayList({ date, meals, onDelete }: { date: string; meals: Meal[]; onDelete: (id: string) => void }) {
  const day = meals.filter((m) => m.date === date).sort((a, b) => a.ts - b.ts);
  if (day.length === 0) return <Text style={{ color: C.muted, marginBottom: 12 }}>Nenhuma refeição neste dia.</Text>;
  return (
    <View>
      <Card style={{ backgroundColor: C.greenLight }}>
        <Text style={{ fontWeight: '600', color: C.text }}>Total do dia</Text>
        <Macros t={sum(day)} />
      </Card>
      {day.map((m) => (
        <Card key={m.id}>
          <View style={{ flexDirection: 'row' }}>
            {m.uri ? <Image source={{ uri: m.uri }} style={{ width: 64, height: 64, borderRadius: 12, marginRight: 12 }} /> : null}
            <View style={{ flex: 1 }}>
              <Text style={{ fontWeight: '600', color: C.text, fontSize: 16 }}>{m.tipo}</Text>
              {m.itens.map((it: Item, i: number) => (
                <Text key={i} style={{ color: C.muted }}>
                  • {it.nome} ({it.porcao}) – {Math.round(it.kcal)} kcal
                </Text>
              ))}
            </View>
          </View>
          <Macros t={m.total} />
          {m.obs ? <Text style={{ color: C.muted, marginTop: 6, fontStyle: 'italic' }}>{m.obs}</Text> : null}
          <Btn title="Apagar" kind="danger" onPress={() => onDelete(m.id)} />
        </Card>
      ))}
    </View>
  );
}

export default function Hoje({ meals, setMeals }: { meals: Meal[]; setMeals: (m: Meal[]) => void }) {
  const [tipo, setTipo] = useState(MEAL_TYPES[0]);
  const [nota, setNota] = useState('');
  const [busy, setBusy] = useState(false);
  const [uri, setUri] = useState<string | undefined>();
  const [res, setRes] = useState<Analysis | null>(null);
  const date = todayStr();

  useEffect(() => {
    const h = new Date().getHours();
    setTipo(h < 9 ? MEAL_TYPES[0] : h < 11 ? MEAL_TYPES[1] : h < 14 ? MEAL_TYPES[3] : h < 18 ? MEAL_TYPES[5] : h < 21 ? MEAL_TYPES[7] : MEAL_TYPES[6]);
  }, []);

  async function run(result: ImagePicker.ImagePickerResult) {
    if (result.canceled || !result.assets || !result.assets[0]) return;
    const a = result.assets[0];
    if (!a.base64) return Alert.alert('Ops', 'Não consegui ler a foto. Tente de novo.');
    setUri(a.uri);
    setRes(null);
    setBusy(true);
    try {
      const cfg = await Store.settings();
      if (!cfg.key) throw new Error('Falta a senha do servidor. Abra a aba Ajustes.');
      const r = await analyzeMeal(cfg.url, cfg.key, a.base64, a.mimeType || 'image/jpeg', tipo, nota);
      setRes(r);
    } catch (e: any) {
      Alert.alert('Não deu certo', e.message || 'Erro desconhecido');
    } finally {
      setBusy(false);
    }
  }

  async function camera() {
    const p = await ImagePicker.requestCameraPermissionsAsync();
    if (!p.granted) return Alert.alert('Permissão', 'Preciso da câmera para fotografar a refeição.');
    run(await ImagePicker.launchCameraAsync({ quality: 0.4, base64: true }));
  }
  async function galeria() {
    run(await ImagePicker.launchImageLibraryAsync({ quality: 0.4, base64: true }));
  }

  function guardar() {
    if (!res) return;
    const m: Meal = { id: String(Date.now()), date, tipo, itens: res.itens, total: res.total, obs: res.obs, uri, ts: Date.now() };
    const next = [...meals, m];
    setMeals(next);
    Store.saveMeals(next);
    setRes(null);
    setUri(undefined);
    setNota('');
  }

  function apagar(id: string) {
    Alert.alert('Apagar refeição?', '', [
      { text: 'Não' },
      { text: 'Apagar', style: 'destructive', onPress: () => { const n = meals.filter((m) => m.id !== id); setMeals(n); Store.saveMeals(n); } },
    ]);
  }

  return (
    <ScrollView contentContainerStyle={{ padding: 16 }}>
      <H>Hoje</H>
      <Card>
        <Text style={{ fontWeight: '600', color: C.text, marginBottom: 8 }}>Qual refeição?</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
          {MEAL_TYPES.map((t) => <Chip key={t} title={t} active={t === tipo} onPress={() => setTipo(t)} />)}
        </View>
        <Input placeholder="Observação (opcional): ex. 2 fatias, sem açúcar" value={nota} onChangeText={setNota} />
        <Btn title="Fotografar refeição" onPress={camera} disabled={busy} />
        <Btn title="Escolher da galeria" kind="ghost" onPress={galeria} disabled={busy} />
      </Card>

      {busy && (
        <Card>
          <ActivityIndicator color={C.green} />
          <Text style={{ textAlign: 'center', color: C.muted, marginTop: 8 }}>Analisando a refeição…</Text>
        </Card>
      )}

      {res && (
        <Card style={{ borderColor: C.green }}>
          {uri ? <Image source={{ uri }} style={{ width: '100%', height: 180, borderRadius: 12, marginBottom: 10 }} /> : null}
          <Text style={{ fontWeight: '600', fontSize: 16, color: C.text }}>{tipo}</Text>
          {res.itens.map((it, i) => (
            <Text key={i} style={{ color: C.text, marginTop: 2 }}>
              • {it.nome} ({it.porcao}) – {Math.round(it.kcal)} kcal
            </Text>
          ))}
          <Macros t={res.total} />
          {res.obs ? <Text style={{ color: C.muted, marginTop: 6, fontStyle: 'italic' }}>{res.obs}</Text> : null}
          <Text style={{ color: C.muted, fontSize: 12, marginTop: 6 }}>Valores estimados pela foto.</Text>
          <Btn title="Salvar no meu dia" onPress={guardar} />
          <Btn title="Descartar" kind="ghost" onPress={() => { setRes(null); setUri(undefined); }} />
        </Card>
      )}

      <DayList date={date} meals={meals} onDelete={apagar} />
    </ScrollView>
  );
}
