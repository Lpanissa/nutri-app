import React, { useEffect, useRef, useState } from 'react';
import { View, Text, ScrollView, Image, ActivityIndicator, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
const PIXEL = 'iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAAFUlEQVR4nGP8//8/AzbAhFV00EoAAFbUAw037MyjAAAAAElFTkSuQmCC';
import * as ImagePicker from 'expo-image-picker';
import { C } from './theme';
import { Meal, MEAL_TYPES, Item } from './types';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Store, todayStr, getUser } from './storage';
import { analyzeMeal, CANCELADO } from './api';
import { Card, Btn, Chip, Input, H, Macros, sum } from './ui';

const ORDEM = ['Café da manhã', 'Lanche da manhã', 'Doce isolado', 'Almoço', 'Sobremesa', 'Lanche da tarde', 'Janta', 'Ceia'];
const ordem = (t: string) => { const i = ORDEM.indexOf(t); return i < 0 ? 99 : i; };

export function DayList({ date, meals, onDelete, hideTotal }: { date: string; meals: Meal[]; onDelete: (id: string) => void; hideTotal?: boolean }) {
  const day = meals.filter((m) => m.date === date).sort((a, b) => (ordem(a.tipo) - ordem(b.tipo)) || (a.ts - b.ts));
  const pendentes = usePend().filter((p) => p.date === date);
  const fila = pendentes.map((p) => (
    <Card key={p.id}>
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <ActivityIndicator color={C.green} />
        <View style={{ flex: 1, marginLeft: 12 }}>
          <Text style={{ fontWeight: '600', color: C.text }}>{p.tipo}</Text>
          <Text style={{ color: C.muted, fontSize: 13 }}>
            {p.tentativa > 1 ? 'A IA está ocupada. Tentando de novo (' + p.tentativa + ' de ' + MAX + ')…' : 'Analisando a refeição…'}
          </Text>
          {p.tentativa > 1 ? <Text style={{ color: C.muted, fontSize: 12, marginTop: 2 }}>Pode sair desta tela, eu continuo tentando e salvo aqui quando conseguir.</Text> : null}
        </View>
      </View>
      <Btn title="Cancelar" kind="ghost" onPress={() => { p.cancel.current = true; }} />
    </Card>
  ));
  if (day.length === 0 && fila.length === 0) return <Text style={{ color: C.muted, marginBottom: 12 }}>Nenhuma refeição neste dia.</Text>;
  return (
    <View>
      {fila}
      {hideTotal ? null : (
        <Card style={{ backgroundColor: C.greenLight }}>
          <Text style={{ fontWeight: '600', color: C.text }}>Total do dia</Text>
          <Macros t={sum(day)} />
        </Card>
      )}
      {day.map((m) => (
        <Card key={m.id}>
          <View style={{ flexDirection: 'row' }}>
            {m.uri ? <Image source={{ uri: m.uri }} style={{ width: 64, height: 64, borderRadius: 12, marginRight: 12 }} /> : null}
            <View style={{ flex: 1 }}>
              <Text style={{ fontWeight: '600', color: C.text, fontSize: 16 }}>{m.tipo}</Text>
              {m.itens.map((it: Item, i: number) => (
                <Text key={i} style={{ color: C.muted }}>
                  • {it.nome} ({it.porcao}) – {Math.round(it.kcal)} kcal
                </Text>
              ))}
            </View>
          </View>
          <Macros t={m.total} />
          {m.obs ? <Text style={{ color: C.muted, marginTop: 6, fontStyle: 'italic' }}>{m.obs}</Text> : null}
          <Btn title="Apagar" kind="danger" onPress={() => onDelete(m.id)} />
        </Card>
      ))}
    </View>
  );
}

function Hero({ meals, label }: { meals: Meal[]; label?: string }) {
  const t = sum(meals);
  const Item = ({ l, v }: { l: string; v: number }) => (
    <View style={{ flex: 1, backgroundColor: 'rgba(255,255,255,0.16)', borderRadius: 14, paddingVertical: 10, alignItems: 'center', marginHorizontal: 3 }}>
      <Text style={{ color: '#fff', fontSize: 17, fontWeight: '700' }}>{Math.round(v)}g</Text>
      <Text style={{ color: '#DDEBDD', fontSize: 11, marginTop: 2 }}>{l}</Text>
    </View>
  );
  return (
    <View style={{ backgroundColor: C.green, borderRadius: 26, padding: 20, marginBottom: 16, shadowColor: '#1F3A2A', shadowOpacity: 0.25, shadowRadius: 16, shadowOffset: { width: 0, height: 8 }, elevation: 6 }}>
      <Text style={{ color: '#DDEBDD', fontSize: 13, letterSpacing: 1 }}>{label || 'HOJE'}</Text>
      <View style={{ flexDirection: 'row', alignItems: 'flex-end', marginTop: 4 }}>
        <Text style={{ color: '#fff', fontSize: 48, fontWeight: '800' }}>{Math.round(t.kcal)}</Text>
        <Text style={{ color: '#DDEBDD', fontSize: 16, marginBottom: 9, marginLeft: 6 }}>kcal</Text>
      </View>
      <Text style={{ color: '#DDEBDD', fontSize: 13, marginBottom: 14 }}>{meals.length === 0 ? 'Nenhuma refeição registrada ainda' : meals.length + (meals.length === 1 ? ' refeição registrada' : ' refeições registradas')}</Text>
      <View style={{ flexDirection: 'row', marginHorizontal: -3 }}>
        <Item l="proteína" v={t.proteina} />
        <Item l="carbo" v={t.carbo} />
        <Item l="gordura" v={t.gordura} />
      </View>
    </View>
  );
}

// ---- Análises em andamento (ficam vivas mesmo se você sair da tela) ----
const MAX = 15;
type Pend = { id: string; tipo: string; date: string; tentativa: number; cancel: { current: boolean } };
let pend: Pend[] = [];
const subs = new Set<() => void>();
const emit = () => subs.forEach((f) => f());
function usePend(): Pend[] {
  const [, force] = useState(0);
  useEffect(() => {
    const fn = () => force((n) => n + 1);
    subs.add(fn);
    return () => { subs.delete(fn); };
  }, []);
  return pend;
}

// Marcas das análises em andamento guardadas no celular: se o Android fechar o app no meio,
// na próxima abertura elas viram o fio vermelho da refeição que não foi lida.
const MARCAS = 'pendmarks';
type Marca = { id: string; uid: string; date: string; tipo: string };
async function lerMarcas(): Promise<Marca[]> {
  try { return JSON.parse((await AsyncStorage.getItem(MARCAS)) || '[]'); } catch { return []; }
}
async function mudarMarcas(f: (m: Marca[]) => Marca[]) {
  try { await AsyncStorage.setItem(MARCAS, JSON.stringify(f(await lerMarcas()))); } catch {}
}
export async function recuperarInterrompidas(u: string, onFail: (date: string, tipo: string) => void) {
  const vivas = new Set(pend.map((x) => x.id));
  const todas = await lerMarcas();
  const minhas = todas.filter((m) => m.uid === u && !vivas.has(m.id));
  if (minhas.length === 0) return;
  await mudarMarcas((l) => l.filter((m) => !(m.uid === u && !vivas.has(m.id))));
  minhas.forEach((m) => onFail(m.date, m.tipo));
}

function tsDoDia(date: string, tipo: string): number {
  if (date === todayStr()) return Date.now();
  // dia anterior: encaixa a refeição na ordem do dia (pelo tipo), não pela hora em que foi registrada
  const [y, mo, d] = date.split('-').map(Number);
  const idx = Math.max(0, MEAL_TYPES.indexOf(tipo));
  return new Date(y, mo - 1, d, 6, 0, 0).getTime() + idx * 60 * 60 * 1000 + (Date.now() % 60000);
}

function iniciarAnalise(base64: string, mediaType: string, tipo: string, nota: string, date: string, uri: string | undefined, onAdd: (m: Meal) => void, onFail: (date: string, tipo: string) => void) {
  const p: Pend = { id: String(Date.now()) + Math.random().toString(36).slice(2, 6), tipo, date, tentativa: 1, cancel: { current: false } };
  pend = [...pend, p];
  emit();
  mudarMarcas((l) => [...l, { id: p.id, uid: getUser(), date, tipo }]);
  analyzeMeal(base64, mediaType, tipo, nota, {
    cancel: p.cancel,
    onTry: (k) => { p.tentativa = k; pend = [...pend]; emit(); },
  })
    .then((r) => {
      if (!r.itens || r.itens.length === 0) {
        Alert.alert('Não achei comida', r.obs || 'Tente de novo com outra foto ou descreva o que você comeu.');
        return;
      }
      onAdd({ id: String(Date.now()) + Math.random().toString(36).slice(2, 6), date, tipo, itens: r.itens, total: r.total, obs: r.obs, uri, ts: tsDoDia(date, tipo) });
    })
    .catch((e: any) => {
      if (e && e.message === CANCELADO) return;
      onFail(date, tipo);
      Alert.alert('Não deu certo', (tipo ? tipo + ': ' : '') + ((e && e.message) || 'Erro desconhecido'));
    })
    .finally(() => {
      pend = pend.filter((x) => x !== p);
      mudarMarcas((l) => l.filter((m) => m.id !== p.id));
      emit();
    });
}

export default function Hoje({ meals, setMeals, onAdd, onFail, date: dateProp, onBack }: { meals: Meal[]; setMeals: (m: Meal[]) => void; onAdd: (m: Meal) => void; onFail: (date: string, tipo: string) => void; date?: string; onBack?: () => void }) {
  const [tipo, setTipo] = useState(MEAL_TYPES[0]);
  const [nota, setNota] = useState('');
  const [digitar, setDigitar] = useState(false);
  const [texto, setTexto] = useState('');
  const date = dateProp || todayStr();
  const outroDia = date !== todayStr();
  const dataBr = date.split('-').reverse().join('/');

  useEffect(() => {
    const h = new Date().getHours();
    if (outroDia) return;
    setTipo(h < 9 ? MEAL_TYPES[0] : h < 11 ? MEAL_TYPES[1] : h < 14 ? MEAL_TYPES[3] : h < 18 ? MEAL_TYPES[5] : h < 21 ? MEAL_TYPES[7] : MEAL_TYPES[6]);
  }, []);

  function run(result: ImagePicker.ImagePickerResult) {
    if (result.canceled || !result.assets || !result.assets[0]) return;
    const a = result.assets[0];
    if (!a.base64) return Alert.alert('Ops', 'Não consegui ler a foto. Tente de novo.');
    iniciarAnalise(a.base64, a.mimeType || 'image/jpeg', tipo, nota, date, a.uri, onAdd, onFail);
    setNota('');
  }

  async function camera() {
    const p = await ImagePicker.requestCameraPermissionsAsync();
    if (!p.granted) return Alert.alert('Permissão', 'Preciso da câmera para fotografar a refeição.');
    run(await ImagePicker.launchCameraAsync({ quality: 0.4, base64: true }));
  }
  async function galeria() {
    run(await ImagePicker.launchImageLibraryAsync({ quality: 0.4, base64: true }));
  }

  function porTexto() {
    const t = texto.trim();
    if (t.length < 3) return Alert.alert('Ops', 'Escreva o que você comeu, por exemplo: 2 ovos mexidos e 1 pão.');
    iniciarAnalise(PIXEL, 'image/png', tipo, 'SEM FOTO, ignore a imagem em branco. O que foi comido: ' + t.slice(0, 220), date, undefined, onAdd, onFail);
    setTexto('');
    setDigitar(false);
  }

  function apagar(id: string) {
    Alert.alert('Apagar refeição?', '', [
      { text: 'Não' },
      { text: 'Apagar', style: 'destructive', onPress: () => { const n = meals.filter((m) => m.id !== id); setMeals(n); Store.saveMeals(n); } },
    ]);
  }

  return (
    <ScrollView contentContainerStyle={{ padding: 16, paddingTop: 10 }}>
      {onBack ? (
        <View style={{ marginBottom: 10 }}>
          <Btn title="‹ Voltar para a agenda" kind="ghost" onPress={onBack} />
        </View>
      ) : null}
      <Hero meals={meals.filter((m) => m.date === date)} label={outroDia ? 'REGISTRANDO EM ' + dataBr : undefined} />
      <Card>
        <Text style={{ fontWeight: '600', color: C.text, marginBottom: 8 }}>Qual refeição?</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
          {MEAL_TYPES.map((t) => <Chip key={t} title={t} active={t === tipo} onPress={() => setTipo(t)} />)}
        </View>
        {!digitar && <Input placeholder="Observação (opcional): ex. 2 fatias, sem açúcar" value={nota} onChangeText={setNota} />}
        <Btn title="Fotografar refeição" icon="camera" onPress={camera} />
        <Btn title="Escolher da galeria" icon="images" kind="ghost" onPress={galeria} />
        <Btn title={digitar ? 'Fechar texto' : 'Digitar o que comi'} icon="create" kind="ghost" onPress={() => setDigitar(!digitar)} />
        {digitar && (
          <View>
            <Input placeholder="Ex.: 2 ovos mexidos, 1 pão com manteiga e café com leite" value={texto} onChangeText={setTexto} multiline style={{ minHeight: 80, textAlignVertical: 'top' }} />
            <Btn title="Calcular pelo texto" icon="flash" onPress={porTexto} />
          </View>
        )}
      </Card>

      <DayList date={date} meals={meals} onDelete={apagar} hideTotal />
      <View style={{ height: 10 }} />
    </ScrollView>
  );
}
