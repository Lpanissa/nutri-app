import React, { useEffect, useRef, useState } from 'react';
import { View, Text, ScrollView, Image, ActivityIndicator, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
const PIXEL = 'iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAAFUlEQVR4nGP8//8/AzbAhFV00EoAAFbUAw037MyjAAAAAElFTkSuQmCC';
import * as ImagePicker from 'expo-image-picker';
import { C } from './theme';
import { Meal, MEAL_TYPES, Item } from './types';
import { Store, todayStr } from './storage';
import { analyzeMeal, Analysis } from './api';
import { Card, Btn, Chip, Input, H, Macros, sum } from './ui';

const ORDEM = ['Café da manhã', 'Lanche da manhã', 'Doce isolado', 'Almoço', 'Sobremesa', 'Lanche da tarde', 'Janta', 'Ceia'];
const ordem = (t: string) => { const i = ORDEM.indexOf(t); return i < 0 ? 99 : i; };

export function DayList({ date, meals, onDelete, hideTotal }: { date: string; meals: Meal[]; onDelete: (id: string) => void; hideTotal?: boolean }) {
  const day = meals.filter((m) => m.date === date).sort((a, b) => (ordem(a.tipo) - ordem(b.tipo)) || (a.ts - b.ts));
  if (day.length === 0) return <Text style={{ color: C.muted, marginBottom: 12 }}>Nenhuma refeição neste dia.</Text>;
  return (
    <View>
      {hideTotal ? null : (
        <Card style={{ backgroundColor: C.greenLight }}>
          <Text style={{ fontWeight: '600', color: C.text }}>Total do dia</Text>
          <Macros t={sum(day)} />
        </Card>
      )}
      {day.map((m) => (
        <Card key={m.id}>
          <View style={{ flexDirection: 'row' }}>
            {m.uri ? <Image source={{ uri: m.uri }} style={{ width: 64, height: 64, borderRadius: 12, marginRight: 12 }} /> : null}
            <View style={{ flex: 1 }}>
              <Text style={{ fontWeight: '600', color: C.text, fontSize: 16 }}>{m.tipo}</Text>
              {m.itens.map((it: Item, i: number) => (
                <Text key={i} style={{ color: C.muted }}>
                  • {it.nome} ({it.porcao}) – {Math.round(it.kcal)} kcal
                </Text>
              ))}
            </View>
          </View>
          <Macros t={m.total} />
          {m.obs ? <Text style={{ color: C.muted, marginTop: 6, fontStyle: 'italic' }}>{m.obs}</Text> : null}
          <Btn title="Apagar" kind="danger" onPress={() => onDelete(m.id)} />
        </Card>
      ))}
    </View>
  );
}

function Hero({ meals, label }: { meals: Meal[]; label?: string }) {
  const t = sum(meals);
  const Item = ({ l, v }: { l: string; v: number }) => (
    <View style={{ flex: 1, backgroundColor: 'rgba(255,255,255,0.16)', borderRadius: 14, paddingVertical: 10, alignItems: 'center', marginHorizontal: 3 }}>
      <Text style={{ color: '#fff', fontSize: 17, fontWeight: '700' }}>{Math.round(v)}g</Text>
      <Text style={{ color: '#DDEBDD', fontSize: 11, marginTop: 2 }}>{l}</Text>
    </View>
  );
  return (
    <View style={{ backgroundColor: C.green, borderRadius: 26, padding: 20, marginBottom: 16, shadowColor: '#1F3A2A', shadowOpacity: 0.25, shadowRadius: 16, shadowOffset: { width: 0, height: 8 }, elevation: 6 }}>
      <Text style={{ color: '#DDEBDD', fontSize: 13, letterSpacing: 1 }}>{label || 'HOJE'}</Text>
      <View style={{ flexDirection: 'row', alignItems: 'flex-end', marginTop: 4 }}>
        <Text style={{ color: '#fff', fontSize: 48, fontWeight: '800' }}>{Math.round(t.kcal)}</Text>
        <Text style={{ color: '#DDEBDD', fontSize: 16, marginBottom: 9, marginLeft: 6 }}>kcal</Text>
      </View>
      <Text style={{ color: '#DDEBDD', fontSize: 13, marginBottom: 14 }}>{meals.length === 0 ? 'Nenhuma refeição registrada ainda' : meals.length + (meals.length === 1 ? ' refeição registrada' : ' refeições registradas')}</Text>
      <View style={{ flexDirection: 'row', marginHorizontal: -3 }}>
        <Item l="proteína" v={t.proteina} />
        <Item l="carbo" v={t.carbo} />
        <Item l="gordura" v={t.gordura} />
      </View>
    </View>
  );
}

export default function Hoje({ meals, setMeals, date: dateProp, onBack }: { meals: Meal[]; setMeals: (m: Meal[]) => void; date?: string; onBack?: () => void }) {
  const [tipo, setTipo] = useState(MEAL_TYPES[0]);
  const [nota, setNota] = useState('');
  const [busy, setBusy] = useState(false);
  const mealsRef = useRef(meals);
  mealsRef.current = meals;
  const [digitar, setDigitar] = useState(false);
  const [texto, setTexto] = useState('');
  const date = dateProp || todayStr();
  const outroDia = date !== todayStr();
  const dataBr = date.split('-').reverse().join('/');

  useEffect(() => {
    const h = new Date().getHours();
    if (outroDia) return;
    setTipo(h < 9 ? MEAL_TYPES[0] : h < 11 ? MEAL_TYPES[1] : h < 14 ? MEAL_TYPES[3] : h < 18 ? MEAL_TYPES[5] : h < 21 ? MEAL_TYPES[7] : MEAL_TYPES[6]);
  }, []);

  async function run(result: ImagePicker.ImagePickerResult) {
    if (result.canceled || !result.assets || !result.assets[0]) return;
    const a = result.assets[0];
    if (!a.base64) return Alert.alert('Ops', 'Não consegui ler a foto. Tente de novo.');
    const t = tipo;
    const n = nota;
    setBusy(true);
    try {
      const r = await analyzeMeal(a.base64, a.mimeType || 'image/jpeg', t, n);
      guardar(r, t, a.uri);
    } catch (e: any) {
      Alert.alert('Não deu certo', e.message || 'Erro desconhecido');
    } finally {
      setBusy(false);
    }
  }

  async function camera() {
    const p = await ImagePicker.requestCameraPermissionsAsync();
    if (!p.granted) return Alert.alert('Permissão', 'Preciso da câmera para fotografar a refeição.');
    run(await ImagePicker.launchCameraAsync({ quality: 0.4, base64: true }));
  }
  async function galeria() {
    run(await ImagePicker.launchImageLibraryAsync({ quality: 0.4, base64: true }));
  }

  async function porTexto() {
    const t = texto.trim();
    if (t.length < 3) return Alert.alert('Ops', 'Escreva o que você comeu, por exemplo: 2 ovos mexidos e 1 pão.');
    const tp = tipo;
    setBusy(true);
    try {
      const r = await analyzeMeal(PIXEL, 'image/png', tp, 'SEM FOTO, ignore a imagem em branco. O que foi comido: ' + t.slice(0, 220));
      guardar(r, tp, undefined);
    } catch (e: any) {
      Alert.alert('Não deu certo', e.message || 'Erro desconhecido');
    } finally {
      setBusy(false);
    }
  }

  // Cada análise já entra direto no dia (lista abaixo), sem passo extra de salvar.
  function guardar(r: Analysis, tp: string, u?: string) {
    if (!r.itens || r.itens.length === 0) {
      Alert.alert('Não achei comida', r.obs || 'Tente de novo com outra foto ou descreva o que você comeu.');
      return;
    }
    const m: Meal = { id: String(Date.now()) + Math.random().toString(36).slice(2, 6), date, tipo: tp, itens: r.itens, total: r.total, obs: r.obs, uri: u, ts: Date.now() };
    const next = [...mealsRef.current, m];
    mealsRef.current = next;
    setMeals(next);
    Store.saveMeals(next);
    setNota('');
    setTexto('');
    setDigitar(false);
  }

  function apagar(id: string) {
    Alert.alert('Apagar refeição?', '', [
      { text: 'Não' },
      { text: 'Apagar', style: 'destructive', onPress: () => { const n = mealsRef.current.filter((m) => m.id !== id); mealsRef.current = n; setMeals(n); Store.saveMeals(n); } },
    ]);
  }

  return (
    <ScrollView contentContainerStyle={{ padding: 16, paddingTop: 10 }}>
      {onBack ? (
        <View style={{ marginBottom: 10 }}>
          <Btn title="‹ Voltar para a agenda" kind="ghost" onPress={onBack} />
        </View>
      ) : null}
      <Hero meals={meals.filter((m) => m.date === date)} label={outroDia ? 'REGISTRANDO EM ' + dataBr : undefined} />
      <Card>
        <Text style={{ fontWeight: '600', color: C.text, marginBottom: 8 }}>Qual refeição?</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
          {MEAL_TYPES.map((t) => <Chip key={t} title={t} active={t === tipo} onPress={() => setTipo(t)} />)}
        </View>
        <Btn title="Fotografar refeição" icon="camera" onPress={camera} disabled={busy} />
        <Btn title="Escolher da galeria" icon="images" kind="ghost" onPress={galeria} disabled={busy} />
        <Btn title={digitar ? 'Fechar texto' : 'Digitar o que comi'} icon="create" kind="ghost" onPress={() => setDigitar(!digitar)} disabled={busy} />
        {digitar && (
          <View>
            <Input placeholder="Ex.: 2 ovos mexidos, 1 pão com manteiga e café com leite" value={texto} onChangeText={setTexto} multiline style={{ minHeight: 80, textAlignVertical: 'top' }} />
            <Btn title="Calcular pelo texto" icon="flash" onPress={porTexto} disabled={busy} />
          </View>
        )}
      </Card>

      {busy && (
        <Card>
          <ActivityIndicator color={C.green} />
          <Text style={{ textAlign: 'center', color: C.muted, marginTop: 8 }}>Analisando a refeição…</Text>
        </Card>
      )}

      <DayList date={date} meals={meals} onDelete={apagar} hideTotal />
      <View style={{ height: 10 }} />
    </ScrollView>
  );
}
