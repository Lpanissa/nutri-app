import { Item, Total } from './types';
import { auth } from './firebase';
import { DEFAULT_URL } from './storage';

export type Analysis = { itens: Item[]; total: Total; obs: string };

export async function analyzeMeal(base64: string, mediaType: string, tipo: string, nota: string): Promise<Analysis> {
  const user = auth.currentUser;
  if (!user) throw new Error('Entre na sua conta primeiro.');
  const token = await user.getIdToken();
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 60000);
  try {
    const r = await fetch(DEFAULT_URL + '/refeicao', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token },
      body: JSON.stringify({ image: base64, mediaType, meal: tipo, note: nota }),
      signal: ctrl.signal,
    });
    if (r.status === 429) throw new Error('Você chegou no limite de análises de hoje. Volte amanhã!');
    if (r.status === 401 || r.status === 403) throw new Error('Sessão expirada. Saia e entre de novo.');
    if (!r.ok) throw new Error('O servidor não conseguiu analisar (código ' + r.status + ').');
    const j = await r.json();
    if (!j || !Array.isArray(j.itens)) throw new Error('Resposta inesperada do servidor.');
    return { itens: j.itens, total: j.total, obs: j.obs || '' };
  } catch (e: any) {
    if (e && e.name === 'AbortError') throw new Error('Demorou demais. Tente de novo.');
    throw e;
  } finally {
    clearTimeout(timer);
  }
}
