import { Item, Total } from './types';

export type Analysis = { itens: Item[]; total: Total; obs: string };

export async function analyzeMeal(
  url: string, key: string, base64: string, mediaType: string, tipo: string, nota: string
): Promise<Analysis> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 60000);
  try {
    const r = await fetch(url.replace(/\/+$/, '') + '/refeicao', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-App-Key': key },
      body: JSON.stringify({ image: base64, mediaType, meal: tipo, note: nota }),
      signal: ctrl.signal,
    });
    if (r.status === 403) throw new Error('Senha do servidor errada (veja em Ajustes).');
    if (!r.ok) throw new Error('O servidor não conseguiu analisar (código ' + r.status + ').');
    const j = await r.json();
    if (!j || !Array.isArray(j.itens)) throw new Error('Resposta inesperada do servidor.');
    return { itens: j.itens, total: j.total, obs: j.obs || '' };
  } catch (e: any) {
    if (e && e.name === 'AbortError') throw new Error('Demorou demais. Tente de novo.');
    throw e;
  } finally {
    clearTimeout(timer);
  }
}
