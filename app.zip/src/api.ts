import { Item, Total } from './types';
import { auth } from './firebase';
import { DEFAULT_URL } from './storage';

export type Analysis = { itens: Item[]; total: Total; obs: string };

export const CANCELADO = '__cancelado__';
const MAX_TENTATIVAS = 15;
const ESPERA_S = 20;

type Opts = { onTry?: (tentativa: number, max: number) => void; cancel?: { current: boolean } };

class Fatal extends Error {}

const dormir = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

// Uma tentativa. Erros "fatais" (login, limite diário, foto inválida) não adiantam tentar de novo.
async function umaVez(base64: string, mediaType: string, tipo: string, nota: string): Promise<Analysis> {
  const user = auth.currentUser;
  if (!user) throw new Fatal('Entre na sua conta primeiro.');
  const token = await user.getIdToken();
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 60000);
  try {
    const r = await fetch(DEFAULT_URL + '/refeicao', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token },
      body: JSON.stringify({ image: base64, mediaType, meal: tipo, note: nota }),
      signal: ctrl.signal,
    });
    if (r.status === 429) throw new Fatal('Você chegou no limite de análises de hoje. Volte amanhã!');
    if (r.status === 401 || r.status === 403) throw new Fatal('Sessão expirada. Saia e entre de novo.');
    if (r.status === 400) throw new Fatal('Essa foto não deu certo (talvez seja grande demais). Tente outra.');
    if (!r.ok) throw new Error('servidor ' + r.status);
    const j = await r.json();
    if (!j || !Array.isArray(j.itens)) throw new Error('resposta inesperada');
    return { itens: j.itens, total: j.total, obs: j.obs || '' };
  } finally {
    clearTimeout(timer);
  }
}

// Tenta até 15 vezes, esperando 20 segundos entre uma e outra (cobre falha passageira e falta de cota por minuto).
export async function analyzeMeal(base64: string, mediaType: string, tipo: string, nota: string, opts: Opts = {}): Promise<Analysis> {
  for (let n = 1; n <= MAX_TENTATIVAS; n++) {
    if (opts.cancel && opts.cancel.current) throw new Error(CANCELADO);
    try {
      return await umaVez(base64, mediaType, tipo, nota);
    } catch (e: any) {
      if (e instanceof Fatal) throw e;
      if (n === MAX_TENTATIVAS) break;
      if (opts.onTry) opts.onTry(n + 1, MAX_TENTATIVAS);
      for (let s = 0; s < ESPERA_S; s++) {
        if (opts.cancel && opts.cancel.current) throw new Error(CANCELADO);
        await dormir(1000);
      }
    }
  }
  throw new Error('A IA não conseguiu fazer a leitura. Tente de novo mais tarde.');
}
