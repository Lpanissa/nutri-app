import { Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { initializeApp, getApps } from 'firebase/app';
import * as FA from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { firebaseConfig } from './firebaseConfig';

const app = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);

function makeAuth() {
  if (Platform.OS === 'web') return FA.getAuth(app);
  try {
    return (FA as any).initializeAuth(app, { persistence: (FA as any).getReactNativePersistence(AsyncStorage) });
  } catch {
    return FA.getAuth(app);
  }
}

export const auth: FA.Auth = makeAuth();
export const db = getFirestore(app);
export { FA };

export function erroBonito(e: any): string {
  const c = String((e && e.code) || '');
  if (c.includes('invalid-email')) return 'Esse e-mail não parece certo.';
  if (c.includes('email-already-in-use')) return 'Já existe uma conta com esse e-mail. Tente entrar.';
  if (c.includes('weak-password')) return 'A senha precisa ter pelo menos 6 caracteres.';
  if (c.includes('invalid-credential') || c.includes('wrong-password') || c.includes('user-not-found')) return 'E-mail ou senha incorretos.';
  if (c.includes('too-many-requests')) return 'Muitas tentativas. Espere um pouco e tente de novo.';
  if (c.includes('network')) return 'Sem internet. Verifique a conexão.';
  if (c.includes('popup-closed') || c.includes('cancelled-popup')) return 'Login com Google cancelado.';
  if (c.includes('popup-blocked')) return 'O navegador bloqueou a janela do Google. Libere pop-ups e tente de novo.';
  if (c.includes('unauthorized-domain')) return 'Este endereço ainda não foi liberado para login com Google.';
  return (e && e.message) || 'Algo deu errado. Tente de novo.';
}
