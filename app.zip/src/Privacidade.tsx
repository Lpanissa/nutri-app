import React from 'react';
import { View, Text, ScrollView, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C } from './theme';
import { PRIV } from './privacyText';
import { Card, H } from './ui';

export default function Privacidade({ onClose }: { onClose: () => void }) {
  return (
    <View style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: C.bg, zIndex: 50 }}>
      <ScrollView contentContainerStyle={{ padding: 16, paddingTop: 48, maxWidth: 720, width: '100%', alignSelf: 'center' }}>
        <TouchableOpacity onPress={onClose} style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 12 }}>
          <Ionicons name="chevron-back" size={24} color={C.green} />
          <Text style={{ color: C.green, fontWeight: '600', fontSize: 16 }}>Voltar</Text>
        </TouchableOpacity>
        <H>Política de privacidade</H>
        {PRIV.map(([t, b]) => (
          <Card key={t}>
            <Text style={{ fontWeight: '700', color: C.text, fontSize: 16, marginBottom: 6 }}>{t}</Text>
            <Text style={{ color: C.text, lineHeight: 21 }}>{b}</Text>
          </Card>
        ))}
      </ScrollView>
    </View>
  );
}
