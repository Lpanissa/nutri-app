import React, { useEffect, useState } from 'react';
import { Modal, View, Text, TouchableOpacity, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C } from './theme';
import { Dlg, DlgButton, onDialog } from './alertShim';

// Pop-up no estilo do Mavité (substitui o alerta padrão do Android).
export default function Dialogo() {
  const [fila, setFila] = useState<Dlg[]>([]);
  useEffect(() => onDialog((d) => setFila((f) => [...f, d])), []);

  const atual = fila[0];
  if (!atual) return null;

  const fechar = (b?: DlgButton) => {
    setFila((f) => f.slice(1));
    if (b && b.onPress) setTimeout(() => b.onPress && b.onPress(), 0);
  };

  const botoes = [...atual.buttons].sort((a, b) => (a.style === 'cancel' ? -1 : 0) - (b.style === 'cancel' ? -1 : 0));
  const perigo = botoes.some((b) => b.style === 'destructive');
  const cancelar = botoes.find((b) => b.style === 'cancel');
  const lado = botoes.length === 2;

  return (
    <Modal transparent animationType="fade" visible statusBarTranslucent onRequestClose={() => fechar(cancelar)}>
      <Pressable
        onPress={() => fechar(cancelar)}
        style={{ flex: 1, backgroundColor: 'rgba(31,58,42,0.45)', alignItems: 'center', justifyContent: 'center', padding: 28 }}
      >
        <Pressable
          onPress={() => {}}
          style={{ width: '100%', maxWidth: 380, backgroundColor: C.card, borderRadius: 26, padding: 22, shadowColor: '#1F3A2A', shadowOpacity: 0.25, shadowRadius: 24, shadowOffset: { width: 0, height: 10 }, elevation: 12 }}
        >
          <View style={{ alignItems: 'center' }}>
            <View style={{ width: 52, height: 52, borderRadius: 26, backgroundColor: perigo ? '#F7ECE8' : C.greenLight, alignItems: 'center', justifyContent: 'center', marginBottom: 12 }}>
              <Ionicons name={perigo ? 'alert-circle-outline' : 'leaf-outline'} size={28} color={perigo ? C.warn : C.green} />
            </View>
            <Text style={{ fontSize: 18, fontWeight: '700', color: C.text, textAlign: 'center' }}>{atual.title}</Text>
            {atual.message ? <Text style={{ fontSize: 14.5, color: C.muted, textAlign: 'center', marginTop: 8, lineHeight: 20 }}>{atual.message}</Text> : null}
          </View>
          <View style={{ flexDirection: lado ? 'row' : 'column', marginTop: 20, marginHorizontal: lado ? -4 : 0 }}>
            {botoes.map((b, i) => {
              const cancel = b.style === 'cancel';
              const destr = b.style === 'destructive';
              const bg = destr ? '#F7ECE8' : cancel ? C.greenLight : C.green;
              const cor = destr ? C.warn : cancel ? C.green : '#fff';
              return (
                <TouchableOpacity
                  key={i}
                  onPress={() => fechar(b)}
                  style={{ flex: lado ? 1 : undefined, backgroundColor: bg, borderRadius: 16, paddingVertical: 14, alignItems: 'center', marginHorizontal: lado ? 4 : 0, marginTop: lado ? 0 : i === 0 ? 0 : 8 }}
                >
                  <Text style={{ color: cor, fontWeight: '600', fontSize: 15 }}>{b.text || 'OK'}</Text>
                </TouchableOpacity>
              );
            })}
          </View>
        </Pressable>
      </Pressable>
    </Modal>
  );
}
