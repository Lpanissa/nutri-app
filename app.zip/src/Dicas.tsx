import React, { useState } from 'react';
import { View, Text, ScrollView, Share, Alert } from 'react-native';
import { C } from './theme';
import { Recipe } from './types';
import { Store } from './storage';
import { Card, Btn, Input, H, Chip } from './ui';

const INFLAMA: { nome: string; porque: string }[] = [
  { nome: 'Açúcar e doces em excesso', porque: 'picos de glicose favorecem a inflamação de baixo grau.' },
  { nome: 'Refrigerantes e sucos de caixinha', porque: 'muito açúcar líquido, absorvido rápido.' },
  { nome: 'Ultraprocessados (salgadinhos, biscoitos recheados, macarrão instantâneo)', porque: 'muita gordura ruim, sódio e aditivos.' },
  { nome: 'Embutidos (salsicha, presunto, mortadela, linguiça)', porque: 'processados com muito sódio e conservantes.' },
  { nome: 'Frituras e gordura trans', porque: 'óleo reaproveitado e gordura trans estão ligados à inflamação.' },
  { nome: 'Farinha branca refinada em excesso', porque: 'sobe a glicose rápido e traz pouca fibra.' },
  { nome: 'Álcool em excesso', porque: 'sobrecarrega o fígado e o intestino.' },
];
const ANTI: string[] = [
  'Peixes como sardinha e salmão (ômega 3)', 'Azeite de oliva extra virgem', 'Folhas verde-escuras (couve, rúcula, espinafre)',
  'Frutas vermelhas e cítricas', 'Cúrcuma (açafrão) com pimenta-do-reino', 'Gengibre e alho', 'Castanhas, nozes e sementes (chia, linhaça)',
  'Feijão, lentilha e grão-de-bico', 'Chá verde',
];

const RECEITAS: Recipe[] = [
  { id: 'r1', titulo: 'Omelete de espinafre e tomate', texto: '2 ovos, um punhado de espinafre, 1/2 tomate picado, sal e pimenta. Bata os ovos, junte o resto e doure em frigideira antiaderente com fio de azeite. Dica: serve com salada.' },
  { id: 'r2', titulo: 'Frango grelhado com legumes assados', texto: 'Tempere o peito de frango com alho, limão, sal e páprica. Asse abobrinha, cenoura e brócolis com azeite a 200 °C por 25 min. Grelhe o frango e sirva junto.' },
  { id: 'r3', titulo: 'Sardinha com salada de grão-de-bico', texto: 'Misture grão-de-bico cozido, tomate, cebola roxa, salsinha, azeite e limão. Coloque sardinha em lata (em água ou azeite) por cima.' },
  { id: 'r4', titulo: 'Creme de abóbora com gengibre', texto: 'Refogue cebola e alho, junte abóbora em cubos, um pedaço de gengibre e água. Cozinhe até amolecer, bata no liquidificador e finalize com azeite e cúrcuma.' },
];

export default function Dicas({ recipes, setRecipes }: { recipes: Recipe[]; setRecipes: (r: Recipe[]) => void }) {
  const [aba, setAba] = useState<'inflama' | 'receitas' | 'minhas'>('inflama');
  const [titulo, setTitulo] = useState('');
  const [texto, setTexto] = useState('');

  function guardarPronta(r: Recipe) {
    if (recipes.some((x) => x.titulo === r.titulo)) return Alert.alert('Essa receita já está nas suas.');
    const n = [...recipes, { ...r, id: String(Date.now()) }];
    setRecipes(n); Store.saveRecipes(n);
    Alert.alert('Salva em "Minhas receitas"');
  }
  function nova() {
    if (!titulo.trim() || !texto.trim()) return Alert.alert('Preencha o nome e o modo de preparo.');
    const n = [...recipes, { id: String(Date.now()), titulo: titulo.trim(), texto: texto.trim() }];
    setRecipes(n); Store.saveRecipes(n);
    setTitulo(''); setTexto('');
  }
  function apagar(id: string) {
    const n = recipes.filter((r) => r.id !== id);
    setRecipes(n); Store.saveRecipes(n);
  }
  const compartilhar = (r: Recipe) => Share.share({ message: `${r.titulo}\n\n${r.texto}` });

  return (
    <ScrollView contentContainerStyle={{ padding: 16 }}>
      <H>Dicas</H>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
        <Chip title="O que inflama" active={aba === 'inflama'} onPress={() => setAba('inflama')} />
        <Chip title="Receitas" active={aba === 'receitas'} onPress={() => setAba('receitas')} />
        <Chip title={`Minhas receitas (${recipes.length})`} active={aba === 'minhas'} onPress={() => setAba('minhas')} />
      </View>

      {aba === 'inflama' && (
        <View>
          <Card>
            <Text style={{ fontWeight: '600', color: C.warn, marginBottom: 6 }}>Alimentos que podem inflamar</Text>
            {INFLAMA.map((i, k) => (
              <Text key={k} style={{ color: C.text, marginBottom: 6 }}>• <Text style={{ fontWeight: '600' }}>{i.nome}</Text>: {i.porque}</Text>
            ))}
          </Card>
          <Card>
            <Text style={{ fontWeight: '600', color: C.green, marginBottom: 6 }}>Alimentos que ajudam a reduzir</Text>
            {ANTI.map((a, k) => <Text key={k} style={{ color: C.text, marginBottom: 4 }}>• {a}</Text>)}
          </Card>
          <Text style={{ color: C.muted, fontSize: 12 }}>Informação geral, não substitui a orientação de um nutricionista ou médico.</Text>
        </View>
      )}

      {aba === 'receitas' && RECEITAS.map((r) => (
        <Card key={r.id}>
          <Text style={{ fontWeight: '600', color: C.text, fontSize: 16 }}>{r.titulo}</Text>
          <Text style={{ color: C.text, marginTop: 6 }}>{r.texto}</Text>
          <Btn title="Salvar nas minhas" kind="ghost" onPress={() => guardarPronta(r)} />
          <Btn title="Compartilhar" kind="ghost" onPress={() => compartilhar(r)} />
        </Card>
      ))}

      {aba === 'minhas' && (
        <View>
          <Card>
            <Text style={{ fontWeight: '600', color: C.text }}>Nova receita</Text>
            <Input placeholder="Nome da receita" value={titulo} onChangeText={setTitulo} />
            <Input placeholder="Ingredientes e modo de preparo" value={texto} onChangeText={setTexto} multiline style={{ minHeight: 90, textAlignVertical: 'top' }} />
            <Btn title="Salvar receita" onPress={nova} />
          </Card>
          {recipes.length === 0 && <Text style={{ color: C.muted }}>Você ainda não salvou nenhuma receita.</Text>}
          {recipes.map((r) => (
            <Card key={r.id}>
              <Text style={{ fontWeight: '600', color: C.text, fontSize: 16 }}>{r.titulo}</Text>
              <Text style={{ color: C.text, marginTop: 6 }}>{r.texto}</Text>
              <Btn title="Compartilhar" kind="ghost" onPress={() => compartilhar(r)} />
              <Btn title="Apagar" kind="danger" onPress={() => apagar(r.id)} />
            </Card>
          ))}
        </View>
      )}
    </ScrollView>
  );
}
